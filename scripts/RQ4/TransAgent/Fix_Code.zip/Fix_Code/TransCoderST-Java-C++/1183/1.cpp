int f_filled(int width, int height, int side_length, int max_ones) { 

  int x = side_length;
  
  vector<int> cnt(x * x, 0); 
  
  for (int i = 0; i < width; ++i) {
    for (int j = 0; j < height; ++j) {
      
      int k = (i % x) * x + (j % x);
      
      ++cnt[k];
    }
  }
  
  sort(cnt.begin(), cnt.end());
  int ans = 0;
  
  for (int i = 0; i < max_ones; ++i)
    ans += cnt[cnt.size() - i - 1];
  
  return ans;
}
