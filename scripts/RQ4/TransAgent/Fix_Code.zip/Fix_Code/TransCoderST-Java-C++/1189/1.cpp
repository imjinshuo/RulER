int f_filled(const std::string& text) { 

    
    std::vector<int> cnt(26, 0);
    
    for (int i = 0; i < text.length(); ++i) {
        
        ++cnt[text[i] - 'a'];
    }
    
    cnt['l' - 'a'] >>= 1;
    cnt['o' - 'a'] >>= 1;
    
    int ans = 1 << 30;
    
    for (char c : "balon") {
        
        ans = std::min(ans, cnt[c - 'a']);
    }
    
    return ans;
}
