int f_filled(const std::string& sentence, const std::string& searchWord) {
    
    std::stringstream ss(sentence);
    std::string word;
    std::vector<std::string> words;

    
    while (ss >> word) { 
        words.push_back(word);
    }

    
    for (size_t i = 0; i < words.size(); ++i) { 
        
        
        if (words[i].substr(0, searchWord.length()) == searchWord) { 
            
            
            return i + 1; 
        }
    }
    
    
    return -1;

}
