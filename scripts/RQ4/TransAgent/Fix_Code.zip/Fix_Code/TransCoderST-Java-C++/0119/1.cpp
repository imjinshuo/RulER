std::vector<int> f_filled(int rowIndex) {
    std::vector<int> f(rowIndex + 1);
    
    for (int i = 0; i < rowIndex + 1; ++i) {
        f[i] = 1;
    }
    
    
    
    for (int i = 2; i < rowIndex + 1; ++i) {
        
        
        
        for (int j = i - 1; j > 0; --j) {
            f[j] = f[j] + f[j - 1];
        }
    }
    
    return f;
}
