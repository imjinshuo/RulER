int f_filled(const std::string& s) { 

    
    std::set<std::string> ss;
    
    int n = s.length();
    
    for (int i = 0; i < n; ++i) {
        
        for (int j = i + 1; j <= n; ++j)
            
            ss.insert(s.substr(i, j - i));
    }
    
    return ss.size();
}
