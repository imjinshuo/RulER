bool f_filled(string s1, string s2) {
    
    int need = 0;
    vector<int> cnt(26, 0); 
    
    for (char c : s1) {
        if (++cnt[c - 'a'] == 1) {
            ++need;
        }
    }
    int m = s1.length(), n = s2.length();
    for (int i = 0; i < n; ++i) {
        int c = s2[i] - 'a';
        if (--cnt[c] == 0) {
            --need;
        }
        if (i >= m) {
            c = s2[i - m] - 'a';
            if (++cnt[c] == 1) {
                ++need;
            }
        }
        if (need == 0) {
            return true;
        }
    }
    return false;
}
