int f_filled(int arr[], int n, int a, int b, int c) {
    
    
    int ans = 0; 
    
    
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            for (int k = j + 1; k < n; ++k) {
                
                if (abs(arr[i] - arr[j]) <= a && abs(arr[j] - arr[k]) <= b 
                    && abs(arr[i] - arr[k]) <= c) {
                    ++ans; 
                }
            }
        }
    }
    return ans; 
}
