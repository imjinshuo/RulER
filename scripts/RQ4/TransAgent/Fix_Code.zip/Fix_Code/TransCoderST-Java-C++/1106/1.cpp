bool f_filled(const std::string& expression) { 
    
    std::stack<char> stk;
    
    
    for (char c : expression) {
        
        
        if (c != '(' && c != ')' && c != ',') {
            stk.push(c);
        } else if (c == ')') {
            
            int t = 0, f = 0;
            
            
            while (!stk.empty() && (stk.top() == 't' || stk.top() == 'f')) {
                
                t += stk.top() == 't' ? 1 : 0;
                f += stk.top() == 'f' ? 1 : 0;
                stk.pop();
            }
            
            
            char op = stk.top();
            stk.pop();
            
            
            c = 'f';
            
            
            if ((op == '!' && f > 0) || (op == '&' && f == 0) || (op == '|' && t > 0)) {
                c = 't';
            }
            
            
            stk.push(c);
        }
    }
    
    
    return !stk.empty() && stk.top() == 't';
}
