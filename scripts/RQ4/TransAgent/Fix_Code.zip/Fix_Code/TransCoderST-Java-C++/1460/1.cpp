bool f_filled(int* target, int* arr, int size) {

    
    std::sort(target, target + size);
    
    std::sort(arr, arr + size);
    
    return std::equal(target, target + size, arr);
}
