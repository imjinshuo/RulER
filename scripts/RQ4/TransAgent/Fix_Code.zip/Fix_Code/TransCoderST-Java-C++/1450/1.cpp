int f_filled(int* startTime, int* endTime, int queryTime, int size) { 

    int ans = 0; 
    for (int i = 0; i < size; ++i) { 
        if (startTime[i] <= queryTime && queryTime <= endTime[i]) { 
            ++ans; 
        }
    }
    return ans; 
}
