bool f_filled(std::string s) {
    
    size_t firstA = s.find('A');
    
    size_t lastA = s.rfind('A');
    
    bool containsLLL = s.find("LLL") != std::string::npos;

    
    return (firstA == lastA) && !containsLLL;
}
