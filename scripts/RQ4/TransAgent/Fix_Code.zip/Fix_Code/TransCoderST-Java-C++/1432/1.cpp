int f_filled(int num) {
    std::string a = std::to_string(num);
    std::string b = a;
    for (int i = 0; i < a.length(); ++i) {
        if (a[i] != '9') {
            a[i] = '9';
            break;
        }
    }
    
    if (b[0] != '1') { 
        
        b[0] = '1'; 
    } else {
        
        for (int i = 1; i < b.length(); ++i) {
            
            if (b[i] != '0' && b[i] != '1') { 
                
                b[i] = '0'; 
                
                break;
            }
        }
    }
    
    return std::stoi(a) - std::stoi(b);
}
