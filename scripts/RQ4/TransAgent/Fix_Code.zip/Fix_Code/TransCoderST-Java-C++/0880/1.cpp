std::string f_filled(const std::string& s, int k) { 

    long long m = 0;
    
    for (int i = 0; i < s.length(); ++i) {
        
        if (isdigit(s[i])) {
            m *= (s[i] - '0');
        } else {
            
            ++m;
        }
    }

    
    for (int i = s.length() - 1;; --i) {
        
        k %= m;

        
        if (k == 0 && !isdigit(s[i])) {
            return std::string(1, s[i]);
        }

        
        if (isdigit(s[i])) {
            m /= (s[i] - '0');
        } else {
            
            --m;
        }
    }
}
