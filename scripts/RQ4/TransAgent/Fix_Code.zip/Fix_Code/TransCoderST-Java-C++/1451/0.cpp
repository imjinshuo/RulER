string f_filled ( string text ) {
  string :: size_type pos = text . find ( ' ' ) ;
  pos = text . find ( ' ' ) ;
  std :: transform ( text . begin ( ) + pos , text . end ( ) , text . begin ( ) , :: tolower ) ;
  pos = text . substr ( 0 , 1 ) . find ( ' ' ) + 1 ;
  return string ( text . begin ( ) + pos , text . end ( ) ) ;
}
