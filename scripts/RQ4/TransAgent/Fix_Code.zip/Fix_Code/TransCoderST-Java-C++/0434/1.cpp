int f_filled(const std::string& s) { 

    int ans = 0;
    std::istringstream stream(s);
    std::string word;
    
    while (stream >> word) {
        
        ++ans;
    }
    
    return ans;
}
