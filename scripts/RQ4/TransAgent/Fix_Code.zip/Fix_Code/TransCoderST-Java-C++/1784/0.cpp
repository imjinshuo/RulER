bool f_filled ( const std :: string & s ) {

    return s.find("01") == std::string::npos; 

}
