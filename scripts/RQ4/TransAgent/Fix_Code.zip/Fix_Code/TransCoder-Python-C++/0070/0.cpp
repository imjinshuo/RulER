int f_filled ( int n ) {
  int a , b ;
  for ( ;
  n ;
  n -- ) a = b = a + b ;
  return b ;
}
