int f_filled(int arr[], int size, int KthIndex) {

    
    map<int, int> dict;
    
    vector<int> vect;
    
    for (int i = 0; i < size; i++) {
        
        if (dict.find(arr[i]) != dict.end()) {
            
            dict[arr[i]] = dict[arr[i]] + 1;
        } else {
            
            dict[arr[i]] = 1;
        }
    }
    
    for (int i = 0; i < size; i++) {
        
        if (dict[arr[i]] > 1) {
            continue;
        } else {
            
            KthIndex = KthIndex - 1;
        }
        
        if (KthIndex == 0) {
            
            return arr[i];
        }
    }
    
    return -1;
}
