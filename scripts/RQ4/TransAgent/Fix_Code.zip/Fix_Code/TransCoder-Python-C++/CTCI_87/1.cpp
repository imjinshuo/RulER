int f_filled(std::vector<int> listy, int num) {

    
    

  int expBackoff = 0 ;  
  int index = 0 ;  
  bool limit = false ;  


  while ( ! limit ) {  

    {
       
      int temp = listy [ index ] ;  
       
       
      if ( temp > num )  
       
  
 limit = true ;  
  
      else {
         
        index = pow(2, expBackoff) ;  
         
         
        expBackoff ++ ;  
         
      }
    }
  }
   
  int low = index / 2 ;  
  int high = index ;  
   
   
  while ( low <= high ) {  
   
     
    int middle = ( high + low ) / 2 ;  
     
    {
       
      int valueAt = listy [ middle ] ;  
       
       
      if ( num < valueAt || valueAt == - 1 )  
       
  
 high = middle - 1 ;  
  
       
      else if ( num > valueAt )  
       
  
 low = middle + 1 ;  
  
       
      else return middle ;  
       
    }
  }
   
  return - 1 ;  
   
}
