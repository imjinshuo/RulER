bool f_filled ( string s , string goal ) {

  return s.length() == goal.length() && (s + s).find(goal) != string::npos;

}
