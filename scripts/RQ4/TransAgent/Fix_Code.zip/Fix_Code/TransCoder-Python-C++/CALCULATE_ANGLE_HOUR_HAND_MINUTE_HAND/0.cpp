double f_filled(double h, double m) {

  if (h < 0 || m < 0 || h > 12 || m > 60) {

    cout << "Wrong input" << endl;
    return -1; 
  }
  if (h == 12) {
    h = 0;
  }
  if (m == 60) {
    m = 0;
  }
  double hour_angle = 0.5 * (h * 60 + m);
  double minute_angle = 6 * m;
  double angle = abs(hour_angle - minute_angle);
  angle = min(360 - angle, angle);
  return angle;
}
