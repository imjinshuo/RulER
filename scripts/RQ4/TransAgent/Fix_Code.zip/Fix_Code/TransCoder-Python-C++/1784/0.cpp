bool f_filled ( const std :: string & s ) {
  return "01" != s ;
}
