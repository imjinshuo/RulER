string f_filled ( int number ) {
  int number_s31 = ( int ) ( number * ( 2 * 32 ) ) ;
  if ( number_s31 > 2 * 32 ) return "ERROR" ;
  if ( number_s31 == ( 2 * 32 ) ) number_s31 = 2 * 32 - 1 ;
  string ans = "" ;
  for ( ;
  number_s31 > 32 ;
  number_s31 -- ) {
    ans = to_string ( number_s31 % 2 ) + ans ;
    number_s31 = number_s31 / 2 ;
  }
  return "." + ans ;
}
