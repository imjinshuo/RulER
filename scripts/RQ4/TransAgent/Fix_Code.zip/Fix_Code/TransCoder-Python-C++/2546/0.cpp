bool f_filled ( string s , string target ) {
  return ( "1" == s ) == ( "1" == target ) ;
}
