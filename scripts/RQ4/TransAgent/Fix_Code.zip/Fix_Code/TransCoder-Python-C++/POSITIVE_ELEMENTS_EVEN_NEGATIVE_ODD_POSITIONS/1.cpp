void f_filled(int* a, int size) { 

    
    int positive = 0 ;
    
    int negative = 1 ;
    
    while (true) {
        
        while (positive < size && a[positive] >= 0) {
            positive = positive + 2;
        }
        
        while (negative < size && a[negative] <= 0) {
            negative = negative + 2;
        }
        
        if (positive < size && negative < size) {
            int temp = a[positive];
            a[positive] = a[negative];
            a[negative] = temp;
        }
        
        else {
            break;
        }
    }
}
