int f_filled(int n, int k) {

  int mod = 1000000007;
