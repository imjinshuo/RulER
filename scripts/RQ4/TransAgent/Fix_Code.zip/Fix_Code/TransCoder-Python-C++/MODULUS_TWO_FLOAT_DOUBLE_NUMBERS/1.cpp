int f_filled(int a, int b) {
