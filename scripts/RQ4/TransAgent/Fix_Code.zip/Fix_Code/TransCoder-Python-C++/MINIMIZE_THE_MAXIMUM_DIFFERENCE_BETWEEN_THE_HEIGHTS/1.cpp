int f_filled(int arr[], int n, int k) {
