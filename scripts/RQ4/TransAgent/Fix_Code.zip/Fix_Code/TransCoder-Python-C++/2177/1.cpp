std::vector<int> f_filled(int num) {

  int x, mod;
  
  x = num / 3;
  mod = num % 3;
  
  
  return mod == 0 ? std::vector<int>{x - 1, x, x + 1} : std::vector<int>{};
  
}
