int f_filled(const std::string& expr) { 

    
    int lenn = expr.length();
    
    
    if (lenn % 2 != 0) return -1;
    
    
    std::deque<char> s;
    
    
    for (int i = 0; i < lenn; i++) {
    
        
        if ((expr[i] == ' ') && (!s.empty())) {
        
            
            if (s.front() == ' ') {
                s.pop_front();
            
            } else {
                s.push_front(expr[i]);
            }
        } else {
            s.push_front(expr[i]);
        }
    }
    int red_len = s.size();
    int n = 0;
    while (!s.empty() && s.front() == ' ') {
        s.pop_front();
        n++;
    }
    
    return (red_len / 2 + n % 2);
    
}
