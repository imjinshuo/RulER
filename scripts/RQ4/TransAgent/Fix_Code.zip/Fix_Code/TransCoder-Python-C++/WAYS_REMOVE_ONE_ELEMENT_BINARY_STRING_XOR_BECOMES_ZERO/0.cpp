int f_filled(string str) {

  int oneCount = 0;
  int zeroCount = 0;
  int n = str.length();
  for (int i = 0; i < n; i += 1) {
    if (str[i] == '1') {
      oneCount++;
    } else if (str[i] == '0') {
      zeroCount++;
    }
  }
  if (oneCount % 2 == 0) {
    return zeroCount;
  }
  return oneCount;
}
