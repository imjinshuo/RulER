bool f_filled ( string phrase ) {
  int table [ 256 ] = { 0 };
  int  
countodd = 0  
  
 ;
    for ( int i = 0 ; i < ( int ) phrase . size ( ) ; i ++ ) {
      int a = ( int ) 'a';
      int z = ( int ) 'z';
      int upper_a = ( int ) 'A';
      int upper_z = ( int ) 'Z';
      int val = ( int ) phrase [ i ];
      int x = - 1 ;
      if ( a <= val && val <= z )  
  
 x = val - a  
  
 ;
      if ( upper_a <= val && val <= upper_z )  
  
 x = val - upper_a  
  
 ;
      if ( x != - 1 ) {
        table [ x ] ++ ;
        if ( table [ x ] % 2 ) countodd ++ ;
        else countodd -- ;
      }
    }
     
    return countodd <= 1  
     
 ;
}
