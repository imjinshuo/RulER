int f_filled ( string text , int s ) {
  int ans = 0 ;
  for ( int i = 1 ;
  i <= 27 ;
  i ++ ) {
    int k = i * s ;

    if (k > text.size()) {  

      break ;
    }
    map < char , int > cnt ;  
    int t = 0 ;               
    for ( int j = 0 ;
    j < text.size() ;
    j ++ ) {
      cnt [ text [ j ] ] ++ ; 
      t += cnt [ text [ j ] ] == s ? 1 : 0 ;  
      t -= cnt [ text [ j ] ] == s + 1 ? 1 : 0 ;  
      if ( j >= k ) {  
        cnt [ text [ j - k ] ] -- ;  
        t += cnt [ text [ j - k ] ] == s ? 1 : 0 ;  
        t -= cnt [ text [ j - k ] ] == s - 1 ? 1 : 0 ;  
      }
      ans += i == t ? 1 : 0 ;  
    }
  }
  return ans ;
}
