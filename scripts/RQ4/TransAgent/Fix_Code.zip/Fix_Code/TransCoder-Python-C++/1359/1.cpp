int f_filled(int n) {

  int mod = 1000000007; 
  int f = 1; 
  for (int i = 2; i <= n; i++) { 
    f = (f * i * (2 * i - 1)) % mod; 
  }
  return f; 
}
