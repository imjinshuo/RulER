int f_filled(int n, int k) {
