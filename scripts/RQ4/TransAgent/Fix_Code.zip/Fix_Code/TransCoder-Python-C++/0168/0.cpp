string f_filled ( int columnNumber ) throw ( ) {
  string res ;
  while ( columnNumber ) {
    columnNumber -- ;
    res . push_back ( char ( ( char ) 'A' + columnNumber % 26 ) ) ;
    columnNumber /= 26 ;
  }
  return res . substr ( 0 , res . size ( ) - 1 ) ;
}
