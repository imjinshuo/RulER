long long f_filled(int n) {

   
  const int N = 10 ;
  long long count = 1 ;
   
   
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
   
     
    count = count * ( N + i - 1 ) ; 
    count = count / i ;
     
  }
   
  return count ;
   
}
