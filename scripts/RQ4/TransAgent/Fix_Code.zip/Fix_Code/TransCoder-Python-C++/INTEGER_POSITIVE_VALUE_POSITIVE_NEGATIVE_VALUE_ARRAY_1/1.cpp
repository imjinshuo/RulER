double f_filled(int arr[], int n) { 

   
  int neg = 0 ;
  int pos = 0 ;
  int sum = 0 ;
   
   
  for ( int i = 0 ;
  i < n ;  
  i ++ ) {
   
     
    sum += arr [ i ] ;
     
     
    if ( ( arr [ i ] < 0 ) )  
     
  
 neg ++ ;
  
     
    else pos ++ ;
     
  }
   
  return ( static_cast<double>(sum) / abs ( neg - pos ) ) ;  
   
}
