int f_filled ( int ranks [ ] ) {
  int ans = 0 , cur = ranks [ 0 ] ;
  for ( int x = 1 ;
  x < ranks [ 0 ] ;
  x ++ ) {
    if ( ranks [ x ] < cur ) {
      cur = x ;
      ans ++ ;
    }
  }
  return ans ;
}
