int f_filled(int n) { 
    
    

  return 1 == n ? 1 : 0.5;
}
