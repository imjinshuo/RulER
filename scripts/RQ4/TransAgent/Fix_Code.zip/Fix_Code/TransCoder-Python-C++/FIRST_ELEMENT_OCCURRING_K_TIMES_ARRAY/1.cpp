int f_filled(int arr[], int n, int k) { 

    
    std::unordered_map<int, int> count_map;  
    
    for (int i = 0; i != n; ++i) {  
        
        if (count_map.find(arr[i]) != count_map.end()) {
            
            count_map[arr[i]]++;  
        } else {
            
            count_map[arr[i]] = 1;  
        }
        
        
    }
    
    for (int i = 0; i != n; ++i) {
        
        if (count_map[arr[i]] == k) {
            
            return arr[i];
        }
        
        
    }
    
    return -1;  
}
