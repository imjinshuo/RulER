int f_filled(int a[], int n) {

    
    if (n == 1) { 
        
        return a[0];
        
    }
    int maxNeg = INT_MIN; 
    int minPos = INT_MAX; 
    int countNeg = 0;     
    int countZero = 0;    
    int prod = 1;         
    
    for (int i = 0; i < n; i++) {
        
        
        if (a[i] == 0) {
            
            countZero++;
            continue;
            
        }
        
        if (a[i] < 0) {
            
            countNeg++;
            maxNeg = std::max(maxNeg, a[i]);
            
        }
        
        if (a[i] > 0) {
            
            minPos = std::min(minPos, a[i]);
            
        }
        
        
        prod *= a[i];
        
    }
    
    if (countZero == n || (countNeg == 0 && countZero > 0)) {
        
        return 0;
        
    }
    
    if (countNeg == 0) {
        return minPos;
    }
    
    if ((countNeg & 1) == 0 && countNeg != 0) {
        
        prod /= maxNeg;
        
    }
    
    
    return prod;
    
}
