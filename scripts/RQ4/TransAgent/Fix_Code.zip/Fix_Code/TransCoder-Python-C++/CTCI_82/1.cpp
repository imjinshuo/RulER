bool f_filled(std::string& str) { 

    

    sort ( str . begin ( ) , str . end ( ) ) ;


    for ( int i = 0 ;
    i < str . size ( ) - 1 ;
    i ++ ) {


        if (str[i] == str[i + 1]) {


            return false;

        }
    }

    return true;

}
