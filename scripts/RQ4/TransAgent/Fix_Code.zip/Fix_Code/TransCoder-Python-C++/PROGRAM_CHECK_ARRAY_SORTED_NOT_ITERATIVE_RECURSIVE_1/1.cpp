bool f_filled(int arr[], int n) {
