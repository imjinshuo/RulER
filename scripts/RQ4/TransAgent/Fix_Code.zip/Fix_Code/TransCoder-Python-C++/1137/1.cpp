int f_filled(int n) {
  int a = 0, b = 1, c = 1; 

  for (int _ = 0; _ < n; ++_) { 

    int next_a = b; 
    int next_b = c; 
    int next_c = a + b + c; 
    a = next_a; 
    b = next_b; 
    c = next_c; 
  }
  return a; 
}
