bool f_filled ( const std::string & s, char c ) { 

  bool oneSeen = false ;
  int i = 0 ;
  int n = s.length() ;

  while ( i < n ) { 
    if ( s[i] == c ) { 
      if ( oneSeen == true ) { 
        return false ; 
      } 
      while ( i < n && s[i] == c ) { 
        i = i + 1 ; 
      } 
      oneSeen = true ; 
    } else {
      i = i + 1 ; 
    }
  }
  return true ;
}
