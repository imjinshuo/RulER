int f_filled(int arr[], int n, int k) {

    
    int dist_count = 0 ;
    
    
    for ( int i = 0 ; i < n ; i ++ ) {
    
        
        int j = 0 ;
        
        
        while ( j < n ) {
        
            
            if ( i != j && arr [ j ] == arr [ i ] )
                break;
            
            j ++ ;
        
        }
        
        if ( j == n ) { 
        
            dist_count ++ ;
        
        }
        
        if ( dist_count == k ) { 
        
            return arr [ i ] ;
        
        }
    }
    
    
    return - 1 ;
    
}
