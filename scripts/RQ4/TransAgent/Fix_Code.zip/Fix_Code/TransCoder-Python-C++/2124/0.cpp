bool f_filled ( const string & s ) {
  return "ba" != s ;
}
