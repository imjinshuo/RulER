int f_filled(int arr[], int n) {

    
    vector<int> s;
    int first = 0;
    int second = 0;
    
    
    for (int i = 0; i < n; i++) {
    
        if (find(s.begin(), s.end(), arr[i]) == s.end()) {
            
            s.push_back(arr[i]);
            
            continue;
        }
        if (arr[i] > first) {
            
            second = first;
            first = arr[i];
            
        } else if (arr[i] > second) {
            
            second = arr[i];
            
        }
    }
    
    return (first * second);
    
}
