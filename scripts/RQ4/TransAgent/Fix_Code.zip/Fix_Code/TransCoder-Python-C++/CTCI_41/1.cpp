Node* f_filled(vector<int>& array, int start, int end) {

   
  if ( start > end )
   
  
 return NULL ;
  
   
  int mid = ( start + end ) / 2 ;
  Node * root = new Node(array [ mid ]) ; 
  root -> left = f_filled ( array , start , mid - 1 ) ;
  root -> right = f_filled ( array , mid + 1 , end ) ;
  return root ;
   
}
