int f_filled(const std::string& s) {
    std::istringstream stream(s);
    std::string word;
    int count = 0;
    while (stream >> word) {
        ++count;
    }

    return count;
}
