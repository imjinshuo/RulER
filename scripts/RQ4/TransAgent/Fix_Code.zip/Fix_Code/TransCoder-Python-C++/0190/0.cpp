inline int f_filled ( int n ) {
  int ans = 0 ;
  for ( int i = 0 ;
  i < 32 ;
  i ++ ) {
    ans |= ( n & 1 ) << ( 31 - i ) ;
    n >>= 1 ;
  }

  return static_cast<int>(static_cast<unsigned int>(ans));

}
