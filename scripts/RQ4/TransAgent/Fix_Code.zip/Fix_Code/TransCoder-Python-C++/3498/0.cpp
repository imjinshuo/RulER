int f_filled ( string s ) {
  int ans = 0 ;

  for (int i = 1; i <= s.length(); ++i) { 
    char c = s[i - 1]; 

    int x = 26 - ( ( char ) c - 'a' ) ;
    ans += i * x ;
  }
  return ans ;
}
