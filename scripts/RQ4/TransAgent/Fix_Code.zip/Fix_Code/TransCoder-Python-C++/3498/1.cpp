int f_filled(string s) {
  int ans = 0;

  for (int i = 1; i <= s.length(); ++i) {

    int x = 26 - ( (char) s[i-1] - 'a' );
    ans += i * x;
  }
  return ans;
}
