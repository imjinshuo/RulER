int f_filled(int n) { 
    
    

    std::string str_n = std::to_string(n);
    std::reverse(str_n.begin(), str_n.end());
    int reversed_n = std::stoi(str_n);
    return abs(n - reversed_n);
}
