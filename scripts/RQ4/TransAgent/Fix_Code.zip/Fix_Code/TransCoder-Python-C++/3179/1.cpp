int f_filled(int n, int k) {

  int a[n];
  a[0] = 1;
  int mod = 1000000007;  
   
  for (; k > 0; k--) {
   
     
    for (int i = 1; i < n; i++) {
     
       
      a[i] = (a[i] + a[i - 1]) % mod;
       
    }
  }
   
  return a[n - 1];
   
}
