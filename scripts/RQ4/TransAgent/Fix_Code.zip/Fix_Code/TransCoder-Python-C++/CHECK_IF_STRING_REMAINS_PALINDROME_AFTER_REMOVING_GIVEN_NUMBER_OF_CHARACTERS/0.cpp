bool f_filled ( string str , int n ) {
  int l = str . length ( ) ;

  if (l >= n) {
    return true;
  }

  return false ;
}
