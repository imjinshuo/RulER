int f_filled(int x) { 

    
    int s = 0, y = x;
    
    
    while (y) {
    
        
        s += y % 10;
        y /= 10;
        
    }
    
    return x % s == 0 ? s : -1;
}
