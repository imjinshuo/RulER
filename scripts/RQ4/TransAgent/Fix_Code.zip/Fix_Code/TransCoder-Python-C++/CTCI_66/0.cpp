static inline int f_filled ( int a , int b ) {

  int bigger = (a < b) ? b : a; 
  int smaller = (a < b) ? a : b; 

  if ( smaller == 0 )
 return 0 ;
  if ( smaller == 1 )
 return bigger ;
  int s = smaller >> 1 ;
  int side1 = f_filled ( s , bigger ) ;
  int side2 = side1 ;
  if ( smaller % 2 == 1 )
 side2 = f_filled ( smaller - s , bigger ) ;
  return side1 + side2 ;
}
