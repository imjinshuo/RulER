int f_filled(int arr[], int n) { 

   
  int x[n];
  
  for (int j = 0; j < n; j++) {
      x[j] = arr[j];
  }
  
  sort(x, x + n);
  
  int count = 1;
   
   
  for (int i = 0; i <= n - 2; i++) 
   
 {
     
    if (x[i] + 1 != x[i + 1]) 
     
 {
       
      count = count + 1;
       
    }
  }
   
  return count;
   
}
