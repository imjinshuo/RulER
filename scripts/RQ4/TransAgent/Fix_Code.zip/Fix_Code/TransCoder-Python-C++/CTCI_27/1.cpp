bool f_filled(const std::string& string) {
