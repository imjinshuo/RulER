int f_filled(int N) {  

    if (N <= 6) {  
        return N;
    }  
    
    int screen[N];
    for (int i = 0; i < N; i++) {
        screen[i] = 0;
    }
    
    
    for (int n = 1; n < 7; n++) {  
        
        screen[n - 1] = n;  
    }
    
    for (int n = 7; n <= N; n++) {  
        
        screen[n - 1] = max(2 * screen[n - 4], max(3 * screen[n - 5], 4 * screen[n - 6]));  
    }
    return screen[N - 1];
}
