long long f_filled(const std::string& s) { 
    
    int n = s.length();
    int l[2] = {0}; 
    int r[2] = {0}; 
    
    
    for (int i = 0; i < n; ++i) {
        r[s[i] - '0']++;
    }
    
    long long ans = 0; 
    
    
    for (int i = 0; i < n; ++i) {
        
        int x = s[i] - '0';
        
        
        r[x]--;
        
        
        ans += 1LL * l[x ^ 1] * r[x ^ 1];
        
        
        l[x]++;
    }
    
    
    return ans;
}
