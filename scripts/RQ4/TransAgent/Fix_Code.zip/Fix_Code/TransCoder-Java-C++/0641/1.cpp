int f_filled(int* q, int& front, int& size, int capacity, const std::string& operation, int value) { 










  if (operation == "insert_front") {
    
    if (size == capacity)
      return 0;
    if (size != 0)
      front = (front - 1 + capacity) % capacity;
    q[front] = value;
    
    size++;
    return 1;
  }
  else if (operation == "insert_last") {
    
    if (size == capacity)
      return 0;
    int idx = (front + size) % capacity;
    q[idx] = value;
    
    size++;
    return 1;
  }
  else if (operation == "delete_front") {
    
    if (size == 0)
      return 0;
    
    front = (front + 1) % capacity;
    
    size--;
    return 1;
  }
  else if (operation == "delete_last") {
    
    if (size == 0)
      return 0;
    
    size--;
    return 1;
  }
  else if (operation == "get_front") {
    
    if (size == 0)
      return -1;
    return q[front];
  }
  else if (operation == "get_rear") {
    
    if (size == 0)
      return -1;
    int idx = (front + size - 1) % capacity;
    return q[idx];
  }
  else if (operation == "isEmpty")
    return size == 0 ? 1 : 0;
  else if (operation == "isFull")
    return size == capacity ? 1 : 0;
  return -1;
}
