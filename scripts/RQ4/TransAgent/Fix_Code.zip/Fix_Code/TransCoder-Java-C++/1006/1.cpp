int f_filled(int n) {
    
    
    deque<int> stk;
    stk.push_back(n);
    
    int k = 0;
    
    for (int x = n - 1; x > 0; --x) {
        
        if (k == 0) {
            int temp = stk.back();
            stk.pop_back();
            stk.push_back(temp * x);
        } 
        
        else if (k == 1) {
            int temp = stk.back();
            stk.pop_back();
            stk.push_back(temp / x);
        } 
        
        else if (k == 2) {
            stk.push_back(x);
        } 
        
        else {
            stk.push_back(-x);
        }
        
        k = (k + 1) % 4;
    }
    
    int sum = 0;
    for (int num : stk) {
        sum += num;
    }
    return sum;
}
