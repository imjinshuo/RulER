int f_filled(const std::string& rings) { 
    
    int d['Z'] = {0}; 
    d['R'] = 1; 
    d['G'] = 2; 
    d['B'] = 4; 
    
    
    int mask[10] = {0};
    
    
    for (int i = 0, n = rings.size(); i < n; i += 2) { 
        
        int c = rings[i]; 
        
        int j = rings[i + 1] - '0'; 
        
        mask[j] |= d[c]; 
    }
    
    
    int ans = 0; 
    
    for (int x : mask) { 
        
        if (x == 7) { 
            ++ans; 
        }
    }
    return ans; 
}
