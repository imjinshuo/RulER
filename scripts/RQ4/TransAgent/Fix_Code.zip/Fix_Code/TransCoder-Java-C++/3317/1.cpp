int f_filled(int n, int x, int y) { 

    
    const int mod = (int) 1e9 + 7;
    
    long long f[n + 1][x + 1];
    
    f[0][0] = 1;
    
    for (int i = 1; i <= n; ++i) {
        
        for (int j = 1; j <= x; ++j) {
            
            
            
            
            
            f[i][j] = (f[i - 1][j] * j % mod + f[i - 1][j - 1] * (x - (j - 1)) % mod) % mod;
        }
    }
    
    long long ans = 0, p = 1;
    
    for (int j = 1; j <= x; ++j) {
        
        p = p * y % mod;
        
        ans = (ans + f[n][j] * p) % mod;
    }
    
    return (int) ans;
}
