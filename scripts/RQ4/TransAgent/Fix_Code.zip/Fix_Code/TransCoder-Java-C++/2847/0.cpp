string f_filled(long long n) {
    vector<int> cnt(10);
    
    for (int i = 9; i > 1; --i) { 
        
        while (n % i == 0) {
            ++cnt[i];
            n /= i;
        }
    }
    if (n > 1) {
        return "-1";
    }
    string str;
    for (int i = 2; i < 10; ++i) {
        while (cnt[i] > 0) {
            str.append(to_string(i)); 
            --cnt[i];
        }
    }
    string ans = str;
    return ans.empty() ? "1" : ans; 
}
