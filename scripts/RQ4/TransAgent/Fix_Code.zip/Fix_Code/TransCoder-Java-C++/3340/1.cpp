bool f_filled(const std::string& num) { 

  
  int f[2] = {0, 0};
  
  for (int i = 0; i < num.length(); ++i)
    
    f[i & 1] += num[i] - '0';
  
  return f[0] == f[1];
}
