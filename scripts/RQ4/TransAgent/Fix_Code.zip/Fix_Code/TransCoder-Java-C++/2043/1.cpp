bool f_filled(int account1, int account2, long long money, long long* balance) {
  
  
  if (account1 > balance[0] || account2 > balance[0] || balance[account1 - 1] < money)  
  {
      
      return false;  
  }
  
  balance[account1 - 1] -= money;
  
  balance[account2 - 1] += money;
  
  return true;
}
