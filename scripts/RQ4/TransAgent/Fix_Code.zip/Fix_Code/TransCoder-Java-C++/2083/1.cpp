long long f_filled(const std::string& s) { 

    
    int cnt[26];
    
    long long ans = 0;
    
    for (char c : s) {
        
        ans += ++cnt[c - 'a'];
    }
    
    return ans;
}
