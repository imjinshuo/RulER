bool f_filled(string s, string p) {
    int i = 0;
    
    
    stringstream ss(p);
    string t;
    while (getline(ss, t, '*')) {
        
        size_t j = s.find(t, i);  
        
        if (j == string::npos) {  
            return false;
        }
        i = j + t.length();  
    }
    return true;
}
