bool f_filled(string s, string p) {
    int i = 0; 

    
    vector<string> parts;
    stringstream ss(p);
    string part;
    while (getline(ss, part, '*')) {
        parts.push_back(part);
    }

    
    for (const string& t : parts) {

        
        
        size_t j = s.find(t, i);

        
        
        if (j == string::npos) {
            return false;
        }

        
        i = j + t.length();
    }

    
    return true;
}
