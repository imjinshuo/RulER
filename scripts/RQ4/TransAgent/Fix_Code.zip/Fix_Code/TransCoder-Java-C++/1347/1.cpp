int f_filled(const std::string& s, const std::string& t) { 

  int cnt[26];
  
  std::fill(cnt, cnt + 26, 0);
  
  for (char c : s) {
    cnt[c - 'a']++;
  }
  
  int ans = 0;
  
  for (char c : t) {
    
    
    if (--cnt[c - 'a'] < 0) {
      ans++;
    }
  }
  
  return ans;
}
