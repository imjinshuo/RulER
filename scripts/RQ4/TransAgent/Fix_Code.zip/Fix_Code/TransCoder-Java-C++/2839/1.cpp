bool f_filled(const std::string& s1, const std::string& s2) { 

  
  int cnt[2][26];
  
  memset(cnt, 0, sizeof(cnt));
  
  for (int i = 0; i < s1.length(); ++i) {
    
    ++cnt[i & 1][s1[i] - 'a'];
    
    --cnt[i & 1][s2[i] - 'a'];
  }
  
  for (int i = 0; i < 26; ++i) {
    if (cnt[0][i] != 0 || cnt[1][i] != 0) {
      
      return false;
    }
  }
  
  return true;
}
