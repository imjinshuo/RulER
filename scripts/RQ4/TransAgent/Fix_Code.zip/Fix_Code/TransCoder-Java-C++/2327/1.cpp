int f_filled(int n, int delay, int forget) { 








    const int mod = (int) 1e9 + 7; 
    int m = (n << 1) + 10; 
    long long d[m]; 
    long long cnt[m]; 
    memset(d, 0, sizeof(d)); 
    memset(cnt, 0, sizeof(cnt)); 
    cnt[1] = 1; 
    
    for (int i = 1; i <= n; ++i) { 
        if (cnt[i] > 0) { 
            d[i] = (d[i] + cnt[i]) % mod; 
            d[i + forget] = (d[i + forget] - cnt[i] + mod) % mod; 
            
            int nxt = i + delay; 
            while (nxt < i + forget) { 
                cnt[nxt] = (cnt[nxt] + cnt[i]) % mod; 
                ++nxt; 
            }
        }
    }
    
    long long ans = 0; 
    for (int i = 1; i <= n; ++i) { 
        ans = (ans + d[i]) % mod; 
    }
    
    return (int) ans; 
}
