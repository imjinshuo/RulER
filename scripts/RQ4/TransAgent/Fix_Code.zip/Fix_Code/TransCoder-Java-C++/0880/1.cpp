string f_filled(const string& s, int k) { 
    
    long m = 0;
    
    for (int i = 0; i < s.size(); ++i) {
        
        if (isdigit(s[i]))
            m *= (s[i] - '0');
        else
            
            ++m;
    }
    
    for (int i = s.size() - 1;; --i) {
        
        k %= m;
        
        if (k == 0 && !isdigit(s[i]))
            return string(1, s[i]);
        
        if (isdigit(s[i]))
            m /= (s[i] - '0');
        else
            
            --m;
    }
    
    return "";
}
