bool f_filled(const std::string& s) {
    
    
    return s.find("A") == s.rfind("A") && s.find("LLL") == std::string::npos;
}
