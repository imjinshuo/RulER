bool f_filled (const std::string& expression) { 
    
    
    std::deque<char> stk;
    
    for (char c : expression) {
        
        if (c != '(' && c != ')' && c != ',')
            stk.push_back(c);
        
        else if (c == ')') {
            
            int t = 0, f = 0;
            
            while (!stk.empty() && (stk.back() == 't' || stk.back() == 'f')) {
                t += stk.back() == 't' ? 1 : 0;
                f += stk.back() == 'f' ? 1 : 0;
                stk.pop_back();
            }
            
            char op = stk.back();
            stk.pop_back();
            
            c = 'f';
            
            if ((op == '!' && f > 0) || (op == '&' && f == 0) || (op == '|' && t > 0))
                c = 't';
            
            stk.push_back(c);
        }
    }
    
    return !stk.empty() && stk.back() == 't';
}
