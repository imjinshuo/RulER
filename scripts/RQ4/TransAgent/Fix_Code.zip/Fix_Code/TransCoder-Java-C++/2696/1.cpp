int f_filled(const std::string& s) {

  
  std::deque<char> stk;
  stk.push_back(' ');

  
  for (auto c : s) {
    
    if ((c == 'B' && stk.front() == 'A') || (c == 'D' && stk.front() == 'C')) {
      
      stk.pop_front();
    } else {
      
      stk.push_back(c);
    }
  }
  
  return stk.size() - 1;
}
