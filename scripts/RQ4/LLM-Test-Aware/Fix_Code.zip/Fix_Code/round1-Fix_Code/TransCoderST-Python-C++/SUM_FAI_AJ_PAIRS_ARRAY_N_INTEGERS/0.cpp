int f_filled ( int a [ ] , int n ) {
  map < int , int > cnt ;
  int ans = 0 ;
  int pre_sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    ans += ( i * a [ i ] ) - pre_sum ;
    pre_sum += a [ i ] ;
    if ( ( a [ i ] - 1 ) < cnt . size ( ) ) ans -= cnt [ a [ i ] - 1 ] ;
    if ( ( a [ i ] + 1 ) < cnt . size ( ) ) ans += cnt [ a [ i ] + 1 ] ;
    if (cnt.find(a[i] - 1) != cnt.end()) ans -= cnt[a[i] - 1]; // Patch
    if (cnt.find(a[i] + 1) != cnt.end()) ans += cnt[a[i] + 1]; // Patch
    cnt [ a [ i ] ] ++ ;
  }
  return ans ;
}


