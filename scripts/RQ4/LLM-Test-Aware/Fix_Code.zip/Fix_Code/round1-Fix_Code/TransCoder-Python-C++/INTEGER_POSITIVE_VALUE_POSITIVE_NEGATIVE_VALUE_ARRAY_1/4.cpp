int f_filled ( int arr [ ] , int n ) {
  int neg = 0 ;
  int pos = 0 ;
  int sum = 0 ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    sum += arr [ i ] ;
    if (arr[i] < 0) { // Patch
        neg++; // Patch
    } // Patch
    else pos ++ ;
  }
  return ( sum / abs ( neg - pos ) ) ;
}


