bool f_filled ( unsigned n ) {
  int count = 0 ;
  if ( ( n > 0 ) && ( ! ( n & ( n - 1 ) ) ) ) {
    while ( ( n > 1 ) && ( n & ( n - 1 ) ) ) {
      n >>= 1 ;
      count ++ ;
    }
    while (n > 1) { // Patch
      n >>= 1; // Patch
      count++; // Patch
    } // Patch
      return true ;
    }
    else {
      return false ;
    }
  }
  return false ;
}


