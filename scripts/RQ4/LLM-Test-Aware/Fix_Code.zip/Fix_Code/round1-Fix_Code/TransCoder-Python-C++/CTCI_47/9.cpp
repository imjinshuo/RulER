    int number_s31 = static_cast<int>(number * (1 << 32)); // Patch
    if (number_s31 >= (1 << 32)) return "ERROR"; // Patch
    if (number_s31 == (1 << 32)) number_s31 = (1 << 32) - 1; // Patch
    std::string ans = ""; // Patch
    for (int i = 0; i < 32; ++i) { // Patch
        ans = std::to_string(number_s31 % 2) + ans; // Patch
        number_s31 = number_s31 >> 1; // Patch
    } // Patch
  int number_s31 = ( int ) ( number * ( 2 * 32 ) ) ;
  if ( number_s31 > 2 * 32 ) return "ERROR" ;
  if ( number_s31 == ( 2 * 32 ) ) number_s31 = 2 * 32 - 1 ;
  string ans = "" ;
  for ( ;
  number_s31 > 32 ;
  number_s31 -- ) {
    ans = to_string ( number_s31 % 2 ) + ans ;
    number_s31 = number_s31 / 2 ;
  }
  return "." + ans ;
}

