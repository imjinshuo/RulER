static inline int f_filled ( int num ) {
    int x, mod; // Patch
    tie(x, mod) = div(num, 3); // Patch
  mod = num ;
  x = mod ? mod - 1 : num ;
  return x == mod ? 0 : x - 1 ;
}

