int f_filled ( int arr [ ] , int n ) {
  vector < int > s ;
  int first = 0 ;
  int second = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if (find(s.begin(), s.end(), arr[i]) == s.end()) { // Patch
      s . push_back ( arr [ i ] ) ;
      continue ;
    }
    if ( ( arr [ i ] > first ) && ( arr [ i ] < second ) ) {
      second = first ;
      first = arr [ i ] ;
    }
    else if ( ( arr [ i ] > second ) && ( arr [ i ] < first ) ) {
      second = arr [ i ] ;
    }
  }
  return ( first * second ) ;
}


