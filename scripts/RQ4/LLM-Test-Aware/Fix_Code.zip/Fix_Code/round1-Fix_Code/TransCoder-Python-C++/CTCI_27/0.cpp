bool f_filled ( const string & string ) {
  if ( string . size ( ) > 128 ) return false ;
  unsigned int checker = 0 ;
  for ( string :: const_iterator it = string . begin ( ) ;
  it != string . end ( ) ;
  ++ it ) {
    unsigned int val = ( * it ) ;
    if ((checker & (1 << val)) > 0) { // Patch
        return false; // Patch
    } // Patch
    checker |= 1 << val ;
  }
  return true ;
}

