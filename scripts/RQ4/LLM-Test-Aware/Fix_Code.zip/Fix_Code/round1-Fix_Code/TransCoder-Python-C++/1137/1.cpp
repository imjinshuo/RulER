int f_filled ( int n ) {
  int a = 0 , b = 1 , c = 1 ;
  for ( ;
  n ;
    for (int i = 0; i < n; ++i) { // Patch
        int next_a = b; // Patch
        int next_b = c; // Patch
        int next_c = a + b + c; // Patch
        a = next_a; // Patch
        b = next_b; // Patch
        c = next_c; // Patch
    } // Patch
  return a ;
}

