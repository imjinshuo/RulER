int f_filled ( int n ) {
  int a = 0 , b = 1 , c = 1 ;
  for ( ;
  n ;
    for (int i = 0; i < n; ++i) { // Patch
        int tempA = b; // Patch
        int tempB = c; // Patch
        c = a + b + c; // Patch
        a = tempA; // Patch
        b = tempB; // Patch
    } // Patch
  return a ;
}

