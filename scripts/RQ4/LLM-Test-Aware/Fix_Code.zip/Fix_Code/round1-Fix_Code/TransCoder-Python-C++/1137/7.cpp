int f_filled ( int n ) {
  int a = 0 , b = 1 , c = 1 ;
  for ( ;
  n ;
    for (int i = 0; i < n; ++i) { // Patch
        int next = a + b + c; // Patch
        a = b; // Patch
        b = c; // Patch
        c = next; // Patch
    } // Patch
  return a ;
}

