int f_filled ( int n ) {
  int a = 0 , b = 1 , c = 1 ;
  for ( ;
  n ;
    for (; n > 0; --n) { // Patch
        int next = a + b + c; // Patch
        a = b; // Patch
        b = c; // Patch
        c = next; // Patch
    } // Patch
  return a ;
}

