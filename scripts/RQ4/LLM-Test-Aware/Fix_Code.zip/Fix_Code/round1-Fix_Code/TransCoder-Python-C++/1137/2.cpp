int f_filled ( int n ) {
  int a = 0 , b = 1 , c = 1 ;
  for ( ;
  n ;
    for (int i = 0; i < n; ++i) { // Patch
        int temp_a = b; // Patch
        int temp_b = c; // Patch
        c = a + b + c; // Patch
        a = temp_a; // Patch
        b = temp_b; // Patch
    } // Patch
  return a ;
}

