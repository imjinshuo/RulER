int f_filled ( string s ) {
  int ans = 0 ;
  for ( int i = 0 , c = s . size ( ) , n = s . size ( ) ;
  i < n ;
  i ++ ) {
    int x = 26 - ( ( char ) s [ i ] - 'a' ) ;
    int x = 26 - ((char)s[i] - 'a'); // Patch
    ans += (i + 1) * x; // Patch
  }
  return ans ;
}

