int f_filled ( int n , int k ) {
    if (n + 1 >= k) { // Patch
        return (k - 1); // Patch
    } // Patch
  else return ( 2 * n + 1 - k ) ;
}


