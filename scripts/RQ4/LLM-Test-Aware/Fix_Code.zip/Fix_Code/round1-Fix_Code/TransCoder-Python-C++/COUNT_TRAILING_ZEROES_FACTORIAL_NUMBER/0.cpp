int f_filled ( int n ) {
  int count = 0 ;
  int i = 5 ;
    while (n / i >= 1) { // Patch
    count += ( int ) ( n / i ) ;
    i *= 5 ;
  }
  return ( int ) ( count ) ;
}


