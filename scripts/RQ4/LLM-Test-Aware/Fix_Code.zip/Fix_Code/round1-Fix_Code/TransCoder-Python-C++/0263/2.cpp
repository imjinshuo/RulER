bool f_filled ( int n ) {
  if ( n < 1 ) return false ;
  for ( int x = 2 ;
    for (int x : {2, 3, 5})  // Patch
  x ++ ) while ( n % x == 0 ) n /= x ;
  return n == 1 ;
}

