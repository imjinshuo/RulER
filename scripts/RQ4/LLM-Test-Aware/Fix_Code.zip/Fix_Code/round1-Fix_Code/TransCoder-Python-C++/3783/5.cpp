int f_filled ( int n ) {
    int reversed_n = stoi(to_string(n)); // Patch
    string reversed_str = to_string(n); // Patch
    reverse(reversed_str.begin(), reversed_str.end()); // Patch
    reversed_n = stoi(reversed_str); // Patch
    return abs(n - reversed_n); // Patch
}

