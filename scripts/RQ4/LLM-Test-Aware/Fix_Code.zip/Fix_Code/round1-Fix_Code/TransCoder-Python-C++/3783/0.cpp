int f_filled ( int n ) {
    string str_n = to_string(n); // Patch
    reverse(str_n.begin(), str_n.end()); // Patch
    int reversed_n = stoi(str_n); // Patch
    return abs(n - reversed_n); // Patch
}

