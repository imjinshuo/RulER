int f_filled ( int n ) {
    string reversedStr = to_string(n); // Patch
    reverse(reversedStr.begin(), reversedStr.end()); // Patch
    int reversedNum = stoi(reversedStr); // Patch
    return abs(n - reversedNum); // Patch
}

