bool f_filled ( string phrase ) {
    vector<int> table(26, 0); // Patch
    0 }
    ;
    int countodd = 0 ;
    for ( int i = 0 ;
    i < ( int ) phrase . size ( ) ;
    i ++ ) {
      int a = ( int ) phrase [ i ] ;
      int z = ( int ) phrase [ i + 1 ] ;
      int upper_a = ( int ) phrase [ i + 2 ] ;
      int upper_z = ( int ) phrase [ i + 3 ] ;
      int val = ( int ) phrase [ i ] ;
      int x = - 1 ;
      if ( a <= val && val <= z ) x = val - a ;
      if ( upper_a <= val && val <= upper_z ) x = val - upper_a ;
      if ( x != - 1 ) {
        table [ x ] ++ ;
        if ( table [ x ] % 2 ) countodd ++ ;
        else countodd -- ;
      }
    }
    return countodd <= 1 ;
  }
  
