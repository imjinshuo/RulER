int f_filled ( int m , int n ) {
    std::vector<int> f(n, 1); // Patch
  f [ 0 ] = 1 ;
  for ( ;
  m > 0 ;
  m -- ) {
    for ( int j = 1 ;
    j < n ;
    j ++ ) {
      f [ j ] += f [ j - 1 ] ;
    }
  }
  return f [ n - 1 ] ;
}

