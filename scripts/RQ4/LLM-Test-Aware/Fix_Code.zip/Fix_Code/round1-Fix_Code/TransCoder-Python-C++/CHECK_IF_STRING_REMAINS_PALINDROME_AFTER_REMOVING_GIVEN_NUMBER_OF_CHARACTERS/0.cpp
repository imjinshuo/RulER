bool f_filled ( string str , int n ) {
  int l = str . length ( ) ;
    if (l >= n) { // Patch
        return true; // Patch
    } // Patch
  return false ;
}


