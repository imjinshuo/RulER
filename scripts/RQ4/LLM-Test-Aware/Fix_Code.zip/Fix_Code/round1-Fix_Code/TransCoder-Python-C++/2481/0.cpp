    return (n > 1 && n & 1) ? n : n >> 1; // Patch
  return n == 1 ? ( n > 1 && n & 1 ) : n >> 1 ;
}

