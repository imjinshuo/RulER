int f_filled ( const string & haystack , const string & needle ) throw ( ) {
  int n = haystack . size ( ) , m = needle . size ( ) ;
  for ( int i = 0 ;
  i < n - m + 1 ;
  i ++ ) {
    if (haystack.substr(i, m) == needle) { // Patch
        return i; // Patch
    } // Patch
  }
  return - 1 ;
}

