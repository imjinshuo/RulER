int f_filled ( int arr [ ] , int n , int key ) {
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if (arr[i] == key) { // Patch
        return i; // Patch
    } // Patch
  }
  return - 1 ;
}


