int f_filled ( string str , int n ) {
  vector < vector < int >> dp ( n , vector < int > ( n , 0 ) ) ;
  vector < vector < bool >> P ( n , vector < bool > ( n , false ) ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) P [ i ] [ i ] = true ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) if ( ( str [ i ] == str [ i + 1 ] ) && ( str [ i ] == str [ i + 1 ] ) ) {
    P [ i ] [ i + 1 ] = true ;
    dp [ i ] [ i + 1 ] = 1 ;
  }
  for ( int gap = 2 ;
  gap < n ;
  gap ++ ) {
    for ( int i = 0 ;
    i < n - gap ;
    i ++ ) {
      int j = gap + i ;
      ;
      if ( ( str [ i ] == str [ j ] && P [ i + 1 ] [ j - 1 ] ) || ( str [ i ] == str [ j ] && P [ i + 1 ] [ j - 1 ] ) ) P [ i ] [ j ] = true ;
      if (str[i] == str[j] && P[i + 1][j - 1]) P[i][j] = true; // Patch
      if (P[i][j]) dp[i][j] = (dp[i][j - 1] + dp[i + 1][j] + 1 - dp[i + 1][j - 1]); // Patch
      else dp [ i ] [ j ] = ( dp [ i ] [ j - 1 ] + dp [ i + 1 ] [ j ] - dp [ i + 1 ] [ j - 1 ] ) ;
    }
  }
  return dp [ 0 ] [ n - 1 ] ;
}


