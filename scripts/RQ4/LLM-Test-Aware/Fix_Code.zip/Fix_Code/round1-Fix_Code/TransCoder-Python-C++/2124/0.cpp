bool f_filled ( const string & s ) {
    return s.find("ba") == string::npos; // Patch
}

