int f_filled ( int target ) throw ( ) {
    vector<int> dp(target + 1, 0); // Patch
  dp [ 0 ] = 0 ;
  for ( int i = 1 ;
  i <= target ;
  i ++ ) {
    int k = i >> 1 ;
    if ( i == 2 * k - 1 ) {
      dp [ i ] = k ;
      continue ;
    }
    dp [ i ] = dp [ 2 * k - 1 - i ] + k + 1 ;
    for ( int j = 0 ;
    j < k - 1 ;
    j ++ ) dp [ i ] = min ( dp [ i ] , dp [ i - ( 2 * ( k - 1 ) - 2 * j ) ] + k - 1 + j + 2 ) ;
  }
  return dp [ target ] ;
}

