static inline int f_filled ( int a , int b ) {
  int bigger = b < a ? a : b ;
    int smaller = b < a ? a : b; // Patch
  if ( smaller == 0 ) return 0 ;
  if ( smaller == 1 ) return bigger ;
  int s = smaller >> 1 ;
  int half_prod = f_filled ( s , bigger ) ;
  if ( smaller % 2 == 0 ) return half_prod + half_prod ;
  return half_prod + half_prod + bigger ;
}

