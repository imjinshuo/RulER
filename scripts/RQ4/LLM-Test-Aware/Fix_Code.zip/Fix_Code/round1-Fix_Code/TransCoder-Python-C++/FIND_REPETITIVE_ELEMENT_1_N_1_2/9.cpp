int f_filled ( int arr [ ] , int n ) {
  int res = 0 ;
  for ( int i = 0 ;
        i = 0;  // Patch
  i ++ ) {
    res = res ^ ( i + 1 ) ^ arr [ i ] ;
  }
  res = res ^ arr [ n - 1 ] ;
  return res ;
}


