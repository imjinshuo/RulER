int f_filled ( int n , int goal , int k ) {
    const int mod = 1000000007; // Patch
  int f [ goal + 1 ] [ goal + 1 ] ;
  f [ 0 ] [ 0 ] = 1 ;
  for ( int i = 1 ;
  i <= goal ;
  i ++ ) {
    for ( int j = 1 ;
    j <= n ;
    j ++ ) {
      f [ i ] [ j ] = f [ i - 1 ] [ j - 1 ] * ( n - j + 1 ) ;
      if ( j > k ) f [ i ] [ j ] += f [ i - 1 ] [ j ] * ( j - k ) ;
      f [ i ] [ j ] %= mod ;
    }
  }
  return f [ goal ] [ n ] ;
}

