    if (a < 0) { // Patch
        a = -a; // Patch
    } // Patch
    if (b < 0) { // Patch
        b = -b; // Patch
    } // Patch
  if ( ( a < 0 ) || ( b < 0 ) ) a = - a ;
  if ( ( b < 0 ) || ( a > b ) ) b = - b ;
  int mod = a ;
  while ( ( mod >= b ) && ( mod < a ) ) mod = mod - b ;
  if ( ( a < 0 ) || ( b < a ) ) return - mod ;
  return mod ;
}


