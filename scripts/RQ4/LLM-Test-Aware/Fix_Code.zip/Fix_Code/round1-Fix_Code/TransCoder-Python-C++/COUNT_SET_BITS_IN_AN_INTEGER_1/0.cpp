int f_filled ( int n ) {
    if (n == 0) { // Patch
        return 0; // Patch
    } // Patch
  else return ( n & 1 ) + f_filled ( n >> 1 ) ;
}


