int f_filled ( string word ) {
  int ans = word . size ( ) , a = ( char ) 'a' ;
  for ( int i = 0 ;
  i < word . size ( ) ;
  i ++ ) {
    int d = abs ( word [ i ] - a ) ;
    ans += min ( d , 26 - d ) ;
    a = word[i]; // Patch
  }
  return ans ;
}

