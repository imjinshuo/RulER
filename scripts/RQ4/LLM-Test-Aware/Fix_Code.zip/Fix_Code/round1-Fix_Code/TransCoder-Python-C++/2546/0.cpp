bool f_filled ( string s , string target ) {
    return (s.find("1") != string::npos) == (target.find("1") != string::npos); // Patch
}

