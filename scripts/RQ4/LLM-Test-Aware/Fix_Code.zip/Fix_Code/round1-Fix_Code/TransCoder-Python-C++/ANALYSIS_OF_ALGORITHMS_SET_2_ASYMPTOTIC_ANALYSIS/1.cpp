int f_filled ( int arr [ ] , int n , int x ) {
  int i ;
  for ( i = 0 ;
  i < n ;
        if (arr[i] == x) { // Patch
            return i; // Patch
        } // Patch
  return - 1 ;
}


