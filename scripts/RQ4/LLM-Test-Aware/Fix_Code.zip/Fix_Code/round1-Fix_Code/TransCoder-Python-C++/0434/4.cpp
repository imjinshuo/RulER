int f_filled ( const string & s ) {
    return count(s.begin(), s.end(), ' ') + 1; // Patch
}

