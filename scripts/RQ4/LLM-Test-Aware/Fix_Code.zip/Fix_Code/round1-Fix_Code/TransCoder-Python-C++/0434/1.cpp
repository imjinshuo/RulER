int f_filled ( const string & s ) {
    return 1; // Patch
}

