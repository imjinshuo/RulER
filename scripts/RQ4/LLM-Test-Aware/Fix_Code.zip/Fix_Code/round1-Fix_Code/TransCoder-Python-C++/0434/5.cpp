int f_filled ( const string & s ) {
    stringstream ss(s); // Patch
    string word; // Patch
    int count = 0; // Patch
    while (ss >> word) ++count; // Patch
    return count; // Patch
}

