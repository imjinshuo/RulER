int f_filled ( const string & s ) {
    istringstream iss(s); // Patch
    int count = 0; // Patch
    string word; // Patch
    while (iss >> word) { // Patch
        ++count; // Patch
    } // Patch
    return count; // Patch
}

