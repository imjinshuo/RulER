int f_filled ( const string & s ) {
    stringstream ss(s); // Patch
    int count = 0; // Patch
    string word; // Patch
    while (ss >> word) { // Patch
        ++count; // Patch
    } // Patch
    return count; // Patch
}

