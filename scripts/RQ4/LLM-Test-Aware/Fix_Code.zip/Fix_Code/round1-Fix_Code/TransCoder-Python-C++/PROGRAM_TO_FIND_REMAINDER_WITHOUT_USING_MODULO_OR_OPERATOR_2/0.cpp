int f_filled ( int num , int divisor ) {
    while (num >= divisor) { // Patch
    num -= divisor ;
    ;
  }
  return num ;
}


