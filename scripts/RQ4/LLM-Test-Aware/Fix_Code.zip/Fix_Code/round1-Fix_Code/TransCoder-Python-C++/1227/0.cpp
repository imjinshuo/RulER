double f_filled ( int n ) {
    return n == 1 ? 1.0 : 0.5; // Patch
}

