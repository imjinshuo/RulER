int f_filled ( int n ) {
    if (n == 0 || n == 1) { // Patch
        return n; // Patch
    } // Patch
  return max ( ( f_filled ( n / 2 ) + f_filled ( n / 3 ) + f_filled ( n / 4 ) ) , n ) ;
}


