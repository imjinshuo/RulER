bool getRemainder(int num, int divisor) { // Patch
    if (divisor == 0) return false; // Patch
    if (divisor < 0) divisor = -divisor; // Patch
    if (num < 0) num = -num; // Patch
    int i = 1; // Patch
    int product = 0; // Patch
    while (product <= num) { // Patch
        product = divisor * i; // Patch
        i++; // Patch
    } // Patch
    return num - (product - divisor); // Patch
} // Patch
  if ( ( divisor == 0 ) || ( divisor < 0 ) ) return false ;
  if ( ( divisor > 0 ) || ( divisor < - divisor ) ) divisor = - divisor ;
  if ( ( num < 0 ) || ( num > - num ) ) num = - num ;
  int i = 1 ;
  int product = 0 ;
  while ( ( product <= num ) && ( product > divisor ) ) {
    product = divisor * i ;
    i ++ ;
  }
  return num - ( product - divisor ) ;
}


