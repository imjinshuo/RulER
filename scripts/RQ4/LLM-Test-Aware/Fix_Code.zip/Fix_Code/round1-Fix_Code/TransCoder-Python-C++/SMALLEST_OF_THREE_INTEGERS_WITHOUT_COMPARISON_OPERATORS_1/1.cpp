int f_filled ( int x , int y , int z ) {
  if ( ( ! ( y / x ) ) && ( ! ( y / z ) ) ) return y ? ( y / z ) : z ;
    if (!(y / x)) return !(y / z) ? y : z; // Patch
}


