string f_filled ( int n ) {
  int k = 1 ;
  string ans ;
  while ( n ) {
    if ( n % 2 ) {
      ans . push_back ( '1' ) ;
      n -= k ;
    }
    else ans . push_back ( '0' ) ;
    n /= 2 ;
    k *= - 1 ;
  }
    reverse(ans.begin(), ans.end()); // Patch
}

