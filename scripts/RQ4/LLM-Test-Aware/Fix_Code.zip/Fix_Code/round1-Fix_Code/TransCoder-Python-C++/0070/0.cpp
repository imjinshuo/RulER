int f_filled ( int n ) {
    int a = 0, b = 1; // Patch
  for ( ;
  n ;
  n -- ) a = b = a + b ;
  return b ;
}

