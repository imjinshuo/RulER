int i = 0; // Patch
while (i <= n - 1) { // Patch
    if (arr[i] == x) return i; // Patch
    i += abs(arr[i] - x); // Patch
} // Patch
  int i = 0 ;
  while ( ( i <= n - 1 ) && ( arr [ i ] == x ) ) {
    if ( ( arr [ i ] == x ) || ( arr [ i ] == 0 ) ) return i ;
    i += abs ( arr [ i ] - x ) ;
  }
  return - 1 ;
}


