int f_filled ( int n , int k ) {
    const int mod = 1000000007; // Patch
  int f [ n + 1 ] [ k + 1 ] ;
  f [ 0 ] [ 0 ] = 1 ;
  for ( int i = 1 ;
  i <= n ;
  i ++ ) { for ( int j = 1 ;
  j <= k ;
  j ++ ) f [ i ] [ j ] = ( f [ i - 1 ] [ j - 1 ] + f [ i - 1 ] [ j ] * ( i - 1 ) ) % mod ;}
  return f [ n ] [ k ] ;
}

