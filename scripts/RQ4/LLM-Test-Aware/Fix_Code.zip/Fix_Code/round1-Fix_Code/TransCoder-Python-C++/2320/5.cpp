int f_filled ( int n ) {
    const int mod = 1000000007; // Patch
    if (n == 0) return 0; // Handle edge case where n might be 0 // Patch
  int f [ n ] ;
  int g [ n ] ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    f [ i ] = g [ i - 1 ] ;
    g [ i ] = ( f [ i - 1 ] + g [ i - 1 ] ) % mod ;
  }
  int v = f [ n - 1 ] + g [ n - 1 ] ;
  return v * v % mod ;
}

