Node * f_filled ( int * array , int start , int end ) {
    if (start > end) { // Patch
        return nullptr; // Patch
    } // Patch
  int mid = ( start + end ) / 2 ;
  Node * root = ( Node * ) array [ mid ] ;
  root -> left = f_filled ( array , start , mid - 1 ) ;
  root -> right = f_filled ( array , mid + 1 , end ) ;
  return root ;
}

