bool f_filled ( string & str ) throw ( ) {
  sort ( str . begin ( ) , str . end ( ) ) ;
  for ( int i = 0 ;
        i < str.length() - 1; // Patch
  i ++ ) {
    if ( str [ i ] == str [ i + 1 ] ) return false ;
  }
  return true ;
}

