int f_filled ( int n ) {
    const long long mod = 1000000007; // Patch
  int f = 1 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) f = ( f * i * ( 2 * i - 1 ) ) % mod ;
  return f ;
}

