int f_filled ( int n , int k ) {
  int * f = new int [ n ] ;
  int * g = new int [ n ] ;
  f [ 0 ] = k ;
  for ( int i = 1 ;
  i < n ;
  ++ i ) {
    f [ i ] = ( f [ i - 1 ] + g [ i - 1 ] ) * ( k - 1 ) ;
    g [ i ] = f [ i - 1 ] ;
  }
  delete [ ] f ;
  delete [ ] g ;
    int result = f[n - 1] + g[n - 1]; // Patch
    delete [] f; // Patch
    delete [] g; // Patch
    return result; // Patch
}

