int f_filled ( string text ) {
    int cnt[26] = {0}; // Patch
  for ( int i = 0 ;
  i < text . length ( ) ;
  ++ i ) ++ cnt [ text [ i ] - 'a' ] ;
  cnt [ 'l' - 'a' ] >>= 1 ;
  cnt [ 'o' - 'a' ] >>= 1 ;
  int ans = 1 << 30 ;
  for ( char c : "balon" ) ans = min ( ans , cnt [ c - 'a' ] ) ;
  return ans ;
}

