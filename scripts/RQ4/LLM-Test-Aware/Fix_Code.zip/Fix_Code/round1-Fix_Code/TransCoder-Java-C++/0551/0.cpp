bool f_filled ( string s ) {
    return s.find("A") == s.rfind("A") && s.find("LLL") == string::npos; // Patch
}

