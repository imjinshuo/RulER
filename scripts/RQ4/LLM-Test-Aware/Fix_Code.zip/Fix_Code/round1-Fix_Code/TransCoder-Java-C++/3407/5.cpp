bool f_filled ( string s , string p ) {
  int i = 0 ;
    for (const auto& t : split(p, '*')) { // Patch
  t < p . size ( ) ;
  t ++ ) {
    int j = s . find ( t , i ) ;
    if ( j == string :: npos ) return false ;
    i = j + t ;
  }
  return true ;
}

