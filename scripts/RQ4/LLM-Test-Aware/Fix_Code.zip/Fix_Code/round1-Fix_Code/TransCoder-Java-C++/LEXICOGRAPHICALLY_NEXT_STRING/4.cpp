string f_filled ( string str ) {
  if ( str == "" ) return "a";
  int i = str . size ( ) - 1;
  while ( str [ i ] == 'z' && i >= 0 ) i --;
  if ( i == - 1 ) str [ i ] = 'a';
    if ( i == -1 ) str += 'a'; // Patch
  return str;
}


