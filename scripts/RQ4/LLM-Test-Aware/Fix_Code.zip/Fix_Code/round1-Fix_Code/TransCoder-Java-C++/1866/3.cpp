int f_filled ( int n , int k ) {
  const int mod = ( int ) 1e9 + 7 ;
    int** f = new int*[n + 1]; // Patch
    for (int i = 0; i <= n; ++i) { // Patch
        f[i] = new int[k + 1]; // Patch
        for (int j = 0; j <= k; ++j) { // Patch
            f[i][j] = 0; // Patch
        } // Patch
    } // Patch
  f [ 0 ] [ 0 ] = 1 ;
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    for ( int j = 1 ;
    j <= k ;
    ++ j ) {
      f [ i ] [ j ] = ( int ) ( ( f [ i - 1 ] [ j - 1 ] + f [ i - 1 ] [ j ] * ( long long ) ( i - 1 ) ) % mod ) ;
    }
  }
  return f [ n ] [ k ] ;
}

