int f_filled ( int n ) {
    int* f = new int[n + 1]; // Patch
    for (int i = 0; i <= n; ++i) { // Patch
        f[i] = 0; // Patch
    } // Patch
  f [ 1 ] = 1 ;
  for ( int i = 2 ;
  i <= n ;
  ++ i ) {
    for ( int j = 1 ;
    j < i ;
    ++ j ) {
      f [ i ] = max ( max ( f [ i ] , f [ i - j ] * j ) , ( i - j ) * j ) ;
    }
  }
  return f [ n ] ;
}

