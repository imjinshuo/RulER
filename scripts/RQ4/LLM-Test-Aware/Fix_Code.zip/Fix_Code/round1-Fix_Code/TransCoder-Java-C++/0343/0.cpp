int f_filled ( int n ) {
    int* f = new int[n + 1]; // Patch
    memset(f, 0, sizeof(int) * (n + 1)); // Patch
  f [ 1 ] = 1 ;
  for ( int i = 2 ;
  i <= n ;
  ++ i ) {
    for ( int j = 1 ;
    j < i ;
    ++ j ) {
      f [ i ] = max ( max ( f [ i ] , f [ i - j ] * j ) , ( i - j ) * j ) ;
    }
  }
  return f [ n ] ;
}

