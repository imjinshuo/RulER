bool f_filled ( string s1 , string s2 ) {
    int cnt[2][26] = {0}; // Patch
  for ( int i = 0 ;
  i < s1 . length ( ) ;
  ++ i ) {
    ++ cnt [ i & 1 ] [ s1 [ i ] - 'a' ] ;
    -- cnt [ i & 1 ] [ s2 [ i ] - 'a' ] ;
  }
  for ( int i = 0 ;
  i < 26 ;
  ++ i ) {
    if ( cnt [ 0 ] [ i ] != 0 || cnt [ 1 ] [ i ] != 0 ) {
      return false ;
    }
  }
  return true ;
}

