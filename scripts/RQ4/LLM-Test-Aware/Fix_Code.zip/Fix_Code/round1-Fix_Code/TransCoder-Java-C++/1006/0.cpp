int f_filled ( int n ) {
  deque < int > stk ;
  stk . push_back ( n ) ;
  int k = 0 ;
  for ( int x = n - 1 ;
  x > 0 ;
  -- x ) {
    if (k == 0) stk.push_back(stk.back() * x); // Patch
    else if ( k == 1 ) stk . push_back ( stk . back ( ) / x ) ;
    else if ( k == 2 ) stk . push_back ( x ) ;
    else stk . push_back ( - x ) ;
    k = ( k + 1 ) % 4 ;
  }
  return stk . size ( ) ;
}

