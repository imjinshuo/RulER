int f_filled ( string s ) {
  deque < char > stk ;
  stk . push_back ( ' ' ) ;
  for ( auto c : s ) {
    if ( ( c == 'B' && stk . front ( ) == 'A' ) || ( c == 'D' && stk . front ( ) == 'C' ) ) stk . pop_front ( ) ;
    stk.pop_front(); // Patch
  }
  return stk . size ( ) - 1 ;
}

