int f_filled ( string s , string t ) {
    int cnt[26] = {0}; // Patch
  for ( char c : s ) cnt [ c - 'a' ] ++ ;
  int ans = 0 ;
  for ( char c : t ) if ( -- cnt [ c - 'a' ] < 0 ) ans ++ ;
  return ans ;
}

