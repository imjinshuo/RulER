long long f_filled ( string s ) {
    int cnt[26] = {0}; // Patch
  long long ans = 0 ;
  for ( char c : s ) ans += ++ cnt [ c - 'a' ] ;
  return ans ;
}

