bool f_filled ( const string & s ) {
    return s.find("01") == string::npos; // Patch
}

