int f_filled ( string rings ) {
    int d[26] = {0}; // Patch
    d['R' - 'A'] = 1; // Patch
    d['G' - 'A'] = 2; // Patch
    d['B' - 'A'] = 4; // Patch
    1 , 2 , 3 , 4 }
    ;
    int mask [ 10 ] ;
    for ( int i = 0 , n = rings . size ( ) ;
    i < n ;
    i += 2 ) {
      int c = rings [ i ] ;
      int j = rings [ i + 1 ] - '0' ;
      mask [ j ] |= d [ c ] ;
    }
    int ans = 0 ;
    for ( int x : mask ) {
      if ( x == 7 ) ++ ans ;
    }
    return ans ;
  }
  
