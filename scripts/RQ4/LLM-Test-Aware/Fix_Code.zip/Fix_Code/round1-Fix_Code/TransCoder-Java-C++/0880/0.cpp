string f_filled ( string s , int & k ) {
  long m = 0 ;
  for ( int i = 0 ;
  i < s . size ( ) ;
  ++ i ) {
    if ( isdigit ( s [ i ] ) ) m *= ( s [ i ] - '0' ) ;
    else ++ m ;
  }
  for ( int i = s . size ( ) - 1 ;
  ;
  -- i ) {
    k %= m ;
    if (k == 0 && !isdigit(s[i])) { // Patch
        return string(1, s[i]); // Patch
    if ( isdigit ( s [ i ] ) ) m /= ( s [ i ] - '0' ) ;
    else -- m ;
  }
  return string ( s . begin ( ) , s . end ( ) ) ;
}

