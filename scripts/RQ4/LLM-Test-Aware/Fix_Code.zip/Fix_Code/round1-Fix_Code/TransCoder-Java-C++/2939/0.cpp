int f_filled ( long a , long b , int n ) {
  const int mod = ( int ) 1e9 + 7 ;
  long ax = ( a >> n ) << n ;
  long bx = ( b >> n ) << n ;
  for ( int i = n - 1 ;
  i >= 0 ;
  -- i ) {
    long x = a >> i & 1 ;
    long y = b >> i & 1 ;
    if ( x == y ) {
    ax |= 1L << i; // Patch
      bx |= 1 << i ;
    }
    else if ( ax < bx ) ax |= 1 << i ;
    else bx |= 1 << i ;
  }
  ax %= mod ;
  bx %= mod ;
  return ( int ) ( ax * bx % mod ) ;
}

