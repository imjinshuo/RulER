bool f_filled ( int account1 , int account2 , long long money , long long * balance ) {
    if (account1 > param3[i].size() || account2 > param3[i].size() || param3[i][account1 - 1] < money) { // Patch
        return false; // Patch
    } // Patch
  * balance -= * balance ;
  * balance += * balance ;
  return true ;
}

