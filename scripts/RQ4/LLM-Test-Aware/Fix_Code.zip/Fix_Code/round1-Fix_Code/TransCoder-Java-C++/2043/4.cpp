bool f_filled ( int account1 , int account2 , long long money , long long * balance ) {
    if (account1 > balance.length || account2 > balance.length || balance[account1 - 1] < money) { // Patch
        return false; // Patch
  * balance -= * balance ;
  * balance += * balance ;
  return true ;
}

