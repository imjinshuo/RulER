bool f_filled ( string expression ) {
  deque < char > stk ;
  for ( char c : expression ) {
    if (c != '(' && c != ')' && c != ',') { // Patch
        stk.push_back(c); // Patch
    else if ( c == ')' ) {
      int t = 0 , f = 0 ;
      while ( stk . front ( ) == 't' || stk . front ( ) == 'f' ) {
        t += stk . front ( ) == 't' ? 1 : 0 ;
        f += stk . front ( ) == 'f' ? 1 : 0 ;
        stk . pop_front ( ) ;
      }
      char op = stk . front ( ) ;
      c = 'f' ;
      if ( ( op == '!' && f > 0 ) || ( op == '&' && f == 0 ) || ( op == '|' && t > 0 ) ) c = 't' ;
      stk . push_back ( c ) ;
    }
  }
  return stk . front ( ) == 't' ;
}

