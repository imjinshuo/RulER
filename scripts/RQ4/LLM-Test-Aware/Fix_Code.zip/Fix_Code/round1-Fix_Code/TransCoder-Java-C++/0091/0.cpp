int f_filled ( string s ) {
  int n = s . size ( ) ;
    int* f = new int[n + 1]; // Patch
  f [ 0 ] = 1 ;
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    if ( s [ i - 1 ] != '0' ) f [ i ] = f [ i - 1 ] ;
    if ( i > 1 && s [ i - 2 ] != '0' && int ( s [ i - 2 ] ) <= 26 ) f [ i ] += f [ i - 2 ] ;
  }
  return f [ n ] ;
}

