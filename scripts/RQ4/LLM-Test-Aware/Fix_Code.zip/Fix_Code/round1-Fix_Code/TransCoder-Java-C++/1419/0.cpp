int f_filled ( string croak_of_frogs ) {
  int n = croak_of_frogs . size ( ) ;
  if ( n % 5 != 0 ) {
    return - 1 ;
  }
    int idx[26]; // Patch
  string s = "croak" ;
  for ( int i = 0 ;
  i < 5 ;
  ++ i ) {
    idx [ s [ i ] - 'a' ] = i ;
  }
  int cnt [ 5 ] ;
  int ans = 0 , x = 0 ;
  for ( int k = 0 ;
  k < n ;
  ++ k ) {
    int i = idx [ croak_of_frogs [ k ] - 'a' ] ;
    ++ cnt [ i ] ;
    if ( i == 0 ) {
      ans = max ( ans , ++ x ) ;
    }
    else {
      if ( -- cnt [ i - 1 ] < 0 ) {
        return - 1 ;
      }
      if ( i == 4 ) {
        -- x ;
      }
    }
  }
  return x > 0 ? - 1 : ans ;
}

