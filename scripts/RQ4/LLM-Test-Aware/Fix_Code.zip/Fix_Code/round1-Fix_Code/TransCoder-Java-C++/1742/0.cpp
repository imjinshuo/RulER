int f_filled ( int low_limit , int high_limit ) {
    int cnt[50] = {0}; // Patch
  for ( int i = low_limit ;
  i <= high_limit ;
  ++ i ) {
    int y = 0 ;
    for ( int x = i ;
    x > 0 ;
    x /= 10 ) y += x % 10 ;
    ++ cnt [ y ] ;
  }
  return accumulate ( cnt , cnt + 50 , 0 ) ;
}

