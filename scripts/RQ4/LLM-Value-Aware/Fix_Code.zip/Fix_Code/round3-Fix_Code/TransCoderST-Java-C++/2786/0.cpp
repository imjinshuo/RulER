long long f_filled ( int * nums , int x ) {
  long long f [ 2 ] ;
    std::fill(f, f + 2, -(1LL << 60)); // Patch
  f [ nums [ 0 ] & 1 ] = nums [ 0 ] ;
  for ( int i = 1 ;
  i < sizeof ( nums ) ;
  ++ i ) {
    int v = nums [ i ] ;
    f [ v & 1 ] = max ( f [ v & 1 ] , f [ v & 1 ^ 1 ] - x ) + v ;
  }
  return max ( f [ 0 ] , f [ 1 ] ) ;
}



