int f_filled ( int num ) {
  string a = to_string ( num ) ;
  string b = a ;
  for ( int i = 0 ;
  i < a . length ( ) ;
  ++ i ) {
    if ( a [ i ] != '9' ) {
    a = replace_all(a, a[i], '9'); // Patch
      break ;
    }
  }
  if ( b [ 0 ] != '1' ) b = b . c_str ( ) + 1 ;
  else {
    for ( int i = 1 ;
    i < b . length ( ) ;
    ++ i ) {
      if ( b [ i ] != '0' && b [ i ] != '1' ) {
        b = b . c_str ( ) + i * 10 + 1 ;
        break ;
      }
    }
  }
  return atoi ( a . c_str ( ) ) - atoi ( b . c_str ( ) ) ;
}



