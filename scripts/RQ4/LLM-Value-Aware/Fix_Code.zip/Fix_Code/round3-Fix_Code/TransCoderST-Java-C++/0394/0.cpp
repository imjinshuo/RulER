string f_filled ( string s ) {
  stack < int > s1 ;
  stack < string > s2 ;
  int num = 0 ;
  string res ;
  for ( char c : s ) {
    if ( '0' <= c && c <= '9' ) num = num * 10 + c - '0' ;
    else if ( c == '[' ) {
      s1 . push ( num ) ;
      s2 . push ( res ) ;
      num = 0 ;
      res = "" ;
    }
    else if ( c == ']' ) {
      string t ;
      for ( int i = 0 , n = s1 . top ( ) ;
      i < n ;
      ++ i ) t += res ;
      res = s2 . top ( ) + t ;
    }
    res += c; // Patch
    s2.pop(); // Patch
  }
  return res ;
}



