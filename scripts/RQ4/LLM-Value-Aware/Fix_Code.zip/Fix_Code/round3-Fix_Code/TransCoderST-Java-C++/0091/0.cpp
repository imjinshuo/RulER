int f_filled ( string s ) {
  int n = s . length ( ) ;
    int* f = new int[n + 1]; // Patch
  f [ 0 ] = 1 ;
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    if ( s [ i - 1 ] != '0' ) f [ i ] = f [ i - 1 ] ;
    if ( i > 1 && s [ i - 2 ] != '0' && atoi ( s . substr ( i - 2 , i - 2 ) . c_str ( ) ) <= 26 ) f [ i ] += f [ i - 2 ] ;
  }
  return f [ n ] ;
}



