string f_filled ( string s ) {
  set < char > ss ;
  for ( char c : s ) ss . insert ( c ) ;
  for ( char a = 'Z' ;
    for (char a = 'Z'; a >= 'A'; --a) { // Patch
  -- a ) {
    if ( ss . find ( a ) != ss . end ( ) && ss . find ( ( char ) ( a + 32 ) ) != ss . end ( ) ) return to_string ( a ) ;
  }
  return "" ;
}



