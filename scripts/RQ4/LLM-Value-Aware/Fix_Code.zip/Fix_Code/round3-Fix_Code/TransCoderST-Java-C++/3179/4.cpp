int f_filled ( int n , int k ) {
  const int mod = ( int ) 1e9 + 7 ;
    int* a = new int[n]; // Patch
  memset ( a , 1 , n ) ;
  while ( k -- > 0 ) {
    for ( int i = 1 ;
    i < n ;
    ++ i ) a [ i ] = ( a [ i ] + a [ i - 1 ] ) % mod ;
  }
  return a [ n - 1 ] ;
}



