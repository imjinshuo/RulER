int f_filled ( int n ) {
    int prime[n + 1]; // Patch
    int sum = 0; // Patch
  memset ( prime , 0 , n + 1 ) ;
  int max = n / 2 ;
  for ( int p = 2 ;
  p <= max ;
  p ++ ) {
    if ( prime [ p ] == 0 ) {
      for ( int i = p * 2 ;
      i <= n ;
      i += p ) {
        prime [ i ] = p ;
      }
    }
  }
  for ( int p = 2 ;
  p <= n ;
  p ++ ) {
    if ( prime [ p ] != 0 ) {
      sum += prime [ p ] ;
    }
    else {
      sum += p ;
    }
  }
  return sum ;
}




