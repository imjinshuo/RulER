int f_filled ( int n , int k ) {
  const int mod = ( int ) 1e9 + 7 ;
    int f[k + 1]; // Patch
    memset(f, 0, sizeof(f)); // Patch
  int s [ k + 2 ] ;
  f [ 0 ] = 1 ;
  memset ( s , 1 , k + 1 ) ;
  s [ 0 ] = 0 ;
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    for ( int j = 1 ;
    j <= k ;
    ++ j ) f [ j ] = ( s [ j + 1 ] - s [ max ( 0 , j - ( i - 1 ) ) ] + mod ) % mod ;
    for ( int j = 1 ;
    j <= k + 1 ;
    ++ j ) s [ j ] = ( s [ j - 1 ] + f [ j - 1 ] ) % mod ;
  }
  return f [ k ] ;
}



