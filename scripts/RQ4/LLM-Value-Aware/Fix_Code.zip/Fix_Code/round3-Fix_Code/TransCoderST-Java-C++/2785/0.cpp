string f_filled ( string s ) {
  vector < char > vs ;
  string :: size_type pos = 0 ;
  for ( string :: size_type i = 0 ;
  i < s . length ( ) ;
  ++ i ) {
    char c = s[i]; // Patch
    char d = tolower(c); // Patch
    if ( c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ) vs . push_back ( c ) ;
  }
  sort ( vs . begin ( ) , vs . end ( ) ) ;
  for ( int i = 0 , j = 0 ;
  i < s . length ( ) ;
  ++ i ) {
    char c = tolower ( s [ i ] ) ;
    if ( c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ) s [ i ] = vs [ j ++ ] ;
  }
  return string ( s . begin ( ) , s . end ( ) ) ;
}



