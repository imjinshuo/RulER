int f_filled ( int * nums , int n ) {
    int* ans = new int[n << 1]; // Patch
  for ( int i = 0 , j = 0 ;
  i < n ;
  ++ i ) {
    ans [ j ++ ] = nums [ i ] ;
    ans [ j ++ ] = nums [ i + n ] ;
  }
  return ans [ n ] ;
}



