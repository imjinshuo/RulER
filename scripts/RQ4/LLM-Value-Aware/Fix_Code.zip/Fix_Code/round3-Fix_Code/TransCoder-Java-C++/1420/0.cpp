int f_filled ( int n , int m , int k ) {
  if ( k == 0 ) {
    return 0 ;
  }
  long long dp [ n + 1 ] [ k + 1 ] [ m + 1 ] ;
  for ( int i = 1 ;
  i <= m ;
  ++ i ) {
    dp [ 1 ] [ 1 ] [ i ] = 1 ;
  }
  for ( int i = 2 ;
  i <= n ;
  ++ i ) {
    for ( int c = 1 ;
    c <= min ( i , k ) ;
    ++ c ) {
      for ( int j = 1 ;
      j <= m ;
      ++ j ) {
        dp [ i ] [ c ] [ j ] = ( dp [ i - 1 ] [ c ] [ j ] * j ) % 1000000007 ;
        for ( int j0 = 1 ;
        j0 < j ;
        ++ j0 ) {
          dp [ i ] [ c ] [ j ] = ( dp [ i ] [ c ] [ j ] + dp [ i - 1 ] [ c - 1 ] [ j0 ] ) % 1000000007 ;
        }
      }
    }
  }
  long long ans = 0 ;
  for ( int i = 1 ;
  i <= m ;
  ++ i ) {
    ans = (ans + dp[n][k][i]) % 1000000007; // Patch
  }
  return ( int ) ( ans ) ;
}



