int f_filled ( int n , int k ) {
  const int mod = ( int ) 1e9 + 7 ;
    int f[k + 1]; // Patch
    int s[k + 2]; // Patch
    f[0] = 1; // Patch
    std::fill(s, s + k + 2, 1); // Patch
    s[0] = 0; // Patch
  int s [ k + 2 ] ;
  f [ 0 ] = 1 ;
  memset ( s , 1 , k ) ;
  s [ 0 ] = 0 ;
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    for ( int j = 1 ;
    j <= k ;
    ++ j ) f [ j ] = ( s [ j + 1 ] - s [ max ( 0 , j - ( i - 1 ) ) ] + mod ) % mod ;
    for ( int j = 1 ;
    j <= k + 1 ;
    ++ j ) s [ j ] = ( s [ j - 1 ] + f [ j - 1 ] ) % mod ;
  }
  return f [ k ] ;
}



