int f_filled ( string s ) {
  set < string > ss ;
  int n = s . size ( ) ;
  for ( int i = 0 ;
  i < n ;
  ++ i ) {
    for ( int j = i + 1 ;
    j <= n ;
    ++ j ) ss . insert ( s . substr ( i , j ) ) ;
  }
    return ss.size(); // Patch
}



