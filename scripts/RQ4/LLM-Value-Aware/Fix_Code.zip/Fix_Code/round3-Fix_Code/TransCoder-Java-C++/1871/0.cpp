bool f_filled ( string s , int min_jump , int max_jump ) {
  int n = s . length ( ) ;
    int pre[n + 1] = {0}; // Patch
  pre [ 1 ] = 1 ;
  bool f [ n ] ;
  f [ 0 ] = true ;
  for ( int i = 1 ;
  i < n ;
  ++ i ) {
    if ( s [ i ] == '0' ) {
      int l = max ( 0 , i - max_jump ) ;
      int r = i - min_jump ;
      f [ i ] = l <= r && pre [ r + 1 ] - pre [ l ] > 0 ;
    }
    pre [ i + 1 ] = pre [ i ] + ( f [ i ] ? 1 : 0 ) ;
  }
  return f [ n - 1 ] ;
}



