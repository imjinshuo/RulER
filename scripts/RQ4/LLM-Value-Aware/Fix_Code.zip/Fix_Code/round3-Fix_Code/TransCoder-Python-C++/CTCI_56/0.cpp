int f_filled ( int x ) {
  if ( x < 0 ) return 0 ;
    int* memo = new int[x + 1]; // Patch
    for (int i = 0; i <= x; ++i) { // Patch
        memo[i] = -1; // Patch
    } // Patch
  memo [ 0 ] = - 1 ;
  memo [ 1 ] = 1 ;
  if ( x >= 1 ) memo [ 1 ] = 1 ;
  if ( x >= 2 ) memo [ 2 ] = memo [ 1 ] + memo [ 0 ] ;
  if ( x > 2 ) for ( int i = 3 ;
  i <= x ;
  i ++ ) memo [ i ] = memo [ i - 1 ] + memo [ i - 2 ] + memo [ i - 3 ] ;
  return memo [ x ] ;
}



