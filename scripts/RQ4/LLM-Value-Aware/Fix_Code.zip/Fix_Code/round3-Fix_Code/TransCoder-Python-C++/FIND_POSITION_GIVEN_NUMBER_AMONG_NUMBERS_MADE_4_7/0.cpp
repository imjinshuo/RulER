int f_filled ( string n ) {
  int i = 0 ;
  int j = n . length ( ) ;
  int pos = 0 ;
  while ( ( i < j ) && ( i < n . length ( ) ) ) {
    if ( n [ i ] == '4' ) pos = pos * 2 + 1; // Patch
    if ( ( n [ i ] == '5' ) || ( n [ i ] == '6' ) ) pos = pos * 2 + 2 ;
    i = i + 1 ;
  }
  return pos ;
}




