int f_filled ( int n ) {
  const int N = 10 ;
    long long count = 1; // Patch
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    count = ( int ) ( count * ( N + i - 1 ) ) ;
    count = ( int ) ( count / i ) ;
  }
  return count ;
}




