string f_filled ( string text , string s ) {
  int m = text . size ( ) ;
  int n = s . size ( ) ;
  vector < vector < int >> f ( m + 1 , vector < int > ( n + 1 ) ) ;
    for (int i = 1; i <= m; i++) { // Patch
  i <= m ;
  i ++ ) {
    for ( int j = 1 ;
    j <= n ;
    j ++ ) {
      if ( text [ i - 1 ] == s [ j - 1 ] ) {
        f [ i ] [ j ] = f [ i - 1 ] [ j - 1 ] + 1 ;
      }
      else {
        f [ i ] [ j ] = max ( f [ i - 1 ] [ j ] , f [ i ] [ j - 1 ] ) ;
      }
    }
  }
  string ans ;
  int i = m , j = n ;
  while ( i || j ) {
    if ( i == 0 ) {
      j -- ;
      ans . push_back ( s [ j ] ) ;
    }
    else if ( j == 0 ) {
      i -- ;
      ans . push_back ( text [ i ] ) ;
    }
    else {
      if ( f [ i ] [ j ] == f [ i - 1 ] [ j ] ) {
        i -- ;
        ans . push_back ( text [ i ] ) ;
      }
      else if ( f [ i ] [ j ] == f [ i ] [ j - 1 ] ) {
        j -- ;
        ans . push_back ( s [ j ] ) ;
      }
      else {
        i -- ;
        ans . push_back ( text [ i ] ) ;
      }
    }
  }
  return ans . substr ( 0 , ans . size ( ) - 1 ) ;
}



