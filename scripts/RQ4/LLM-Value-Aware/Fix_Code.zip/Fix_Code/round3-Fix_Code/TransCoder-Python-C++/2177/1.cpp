static inline int f_filled ( int num ) {
    int x = num / 3; // Patch
    int mod = num % 3; // Patch
    mod = num % 3; // Patch
    x = num / 3; // Patch
    mod = num % 3; // Patch
    x = num / 3; // Patch
  mod = num ;
  x = mod ? mod - 1 : num ;
  return x == mod ? 0 : x - 1 ;
}



