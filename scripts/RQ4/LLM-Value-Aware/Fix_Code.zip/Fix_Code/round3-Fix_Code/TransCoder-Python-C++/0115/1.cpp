int f_filled ( string s , string t ) {
  int m = s . size ( ) , n = t . size ( ) ;
    vector<vector<int>> f(m + 1, vector<int>(n + 1)); // Patch
  for ( int i = 0 ;
  i < m + 1 ;
  i ++ ) f [ i ] [ 0 ] = 1 ;
  for ( int i = 0 , a = s . size ( ) , b = t . size ( ) ;
  i < m ;
  i ++ ) { for ( int j = 0 , b = t . size ( ) ;
  j < m ;
  j ++ ) {
    f [ i ] [ j ] = f [ i - 1 ] [ j ] ;
    if ( a == b ) f [ i ] [ j ] += f [ i - 1 ] [ j - 1 ] ;
  }}
  return f [ m ] [ n ] ;
}



