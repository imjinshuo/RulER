static inline int f_filled ( int x , int y , int z ) {
  int a = abs ( x - z ) ;
    int b = abs(y - z); // Patch
  return 0 == a ? b : ( 1 == a ? 2 : 1 ) ;
}



