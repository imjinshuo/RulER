int f_filled ( int n , int k ) throw ( ) {
    const int mod = 1000000007; // Patch
  int f [ k + 1 ] = {
    1 }
    ;
    int s [ k + 2 ] = {
      0 }
      ;
      for ( int i = 1 ;
      i <= n ;
      i ++ ) {
        for ( int j = 1 ;
        j <= k ;
        j ++ ) {
          f [ j ] = ( s [ j + 1 ] - s [ max ( 0 , j - ( i - 1 ) ) ] ) % mod ;
        }
        for ( int j = 1 ;
        j <= k ;
        j ++ ) {
          s [ j ] = ( s [ j - 1 ] + f [ j - 1 ] ) % mod ;
        }
      }
      return f [ k ] ;
    }
    


