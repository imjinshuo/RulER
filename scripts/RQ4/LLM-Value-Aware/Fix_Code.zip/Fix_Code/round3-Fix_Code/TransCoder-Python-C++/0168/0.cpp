string f_filled ( int columnNumber ) throw ( ) {
  string res ;
  while ( columnNumber ) {
    columnNumber -- ;
    res . push_back ( char ( ( char ) 'A' + columnNumber % 26 ) ) ;
    columnNumber /= 26 ;
  }
    reverse(res.begin(), res.end()); // Patch
}



