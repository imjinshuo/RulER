inline int f_filled ( int n ) {
    unsigned int ans = 0; // Patch
  for ( int i = 0 ;
  i < 32 ;
  i ++ ) {
    ans |= ( n & 1 ) << ( 31 - i ) ;
    n >>= 1 ;
  }
  return ans ;
}



