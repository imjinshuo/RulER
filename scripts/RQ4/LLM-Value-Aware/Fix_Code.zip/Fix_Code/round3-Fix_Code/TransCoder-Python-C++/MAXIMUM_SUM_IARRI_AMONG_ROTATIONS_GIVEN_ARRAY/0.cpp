int f_filled ( int arr [ ] , int n ) {
    #include <climits> // Patch
    long long res = LLONG_MIN; // Patch
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    int currSum = 0 ;
    for ( int j = 0 ;
    j <= n ;
    j ++ ) {
      int index = ( int ) ( ( i + j ) % n ) ;
      currSum += j * arr [ index ] ;
    }
    res = max ( res , currSum ) ;
  }
  return res ;
}




