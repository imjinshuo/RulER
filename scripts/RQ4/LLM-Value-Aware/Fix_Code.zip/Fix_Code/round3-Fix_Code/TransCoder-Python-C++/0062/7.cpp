int f_filled ( int m , int n ) {
    int f[n]; // Patch
    for (int i = 0; i < n; i++) { // Patch
        f[i] = 1; // Patch
    } // Patch
  f [ 0 ] = 1 ;
  for ( ;
  m > 0 ;
  m -- ) {
    for ( int j = 1 ;
    j < n ;
    j ++ ) {
      f [ j ] += f [ j - 1 ] ;
    }
  }
  return f [ n - 1 ] ;
}



