int f_filled(int *nums, int goal, int n = 5) {
    unordered_map<long long, int> cnt;
    cnt[0] = 1;
    long long ans = 0, s = 0;
    for (int i = 0; i < n; ++i) { // Patch
        s += nums[i];
        auto it = cnt.find(s - goal);
        if (it != cnt.end()) ans += it->second;
        cnt[s] = cnt[s] + 1;
    }
    return static_cast<int>(ans);
}


