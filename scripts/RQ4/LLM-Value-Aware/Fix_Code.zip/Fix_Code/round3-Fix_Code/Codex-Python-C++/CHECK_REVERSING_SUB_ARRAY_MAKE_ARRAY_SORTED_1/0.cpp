bool f_filled ( int arr [ ], int n ) {
        if ( n == 1 ) {
            return true;
        }
        int i = 1;
        for ( i = 1; i < n; i++ ) {
            if ( arr [ i - 1 ] < arr [ i ] ) {
                if ( i == n ) {
                    return true;
                }
            }
        }
        int j = i;
    while (j < n && arr[j] < arr[j - 1]) { // Patch
            if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) {
                return false;
            }
            j++;
        }
        if ( j == n ) {
            return true;
        }
        int k = j;
        if ( arr [ k ] < arr [ i - 1 ] ) {
            return false;
        }
        while ( k > 1 && k < n ) {
            if ( arr [ k ] < arr [ k - 1 ] ) {
                return false;
            }
            k++;
        }
        return true;
    }




