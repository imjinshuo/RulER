int f_filled(int *nums, int k) {
    unordered_map<int, int> d;
    d[0] = -1;
    int ans = 0, s = 0; // Patch
    vector<int> v;
    int size = 0;
    while (size < 1000000) {
        v.push_back(nums[size]);
        size++;
        if (size >= v.size() || nums[size - 1] == INT_MAX) break;
    }
    for (int i = 0; i < v.size(); ++i) {
        s += v[i];
        if (d.count(s - k)) ans = max(ans, i - d[s - k]);
        if (!d.count(s)) d[s] = i;
    }
    return ans;
}


