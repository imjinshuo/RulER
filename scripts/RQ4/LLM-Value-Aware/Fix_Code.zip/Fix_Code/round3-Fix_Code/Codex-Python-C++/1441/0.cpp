string f_filled(int *target, int n) {
    vector<string> ans;
    int cur = 1;
    for (int i = 0; i < n; ++i) { // Patch
        int x = target[i];
        while (cur < x) {
            ans.push_back("Push");
            ans.push_back("Pop");
            cur += 1;
        }
        ans.push_back("Push");
        cur += 1;
    }
    string res = "[";
    for (size_t i = 0; i < ans.size(); ++i) {
        if (i > 0) res += ", ";
        res += "'" + ans[i] + "'";
    }
    res += "]";
    return res;
}


