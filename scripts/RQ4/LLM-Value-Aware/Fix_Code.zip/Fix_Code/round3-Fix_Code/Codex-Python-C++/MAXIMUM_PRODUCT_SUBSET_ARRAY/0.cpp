int f_filled ( int a [ ] , int n ) {
    if ( n == 1 )
        return a [ 0 ] ;
    int max_neg = -999999999; // Patch
    int count_neg = 0 ;
    int count_zero = 0 ;
    int prod = 1 ;
    for ( int i = 0 ; i < n ; i ++ ) {
        if ( a [ i ] == 0 ) {
            count_zero += 1 ;
            continue ;
        }
        if ( a [ i ] < 0 ) {
            count_neg += 1 ;
            max_neg = max ( max_neg , a [ i ] ) ;
        }
        prod = prod * a [ i ] ;
    }
    if ( count_zero == n )
        return 0 ;
    if ( count_neg & 1 ) {
        if ( ( count_neg == 1 && count_zero > 0 && count_zero + count_neg == n ) )
            return 0 ;
        prod = ( int ) ( prod / max_neg ) ;
    }
    return prod ;
    }




