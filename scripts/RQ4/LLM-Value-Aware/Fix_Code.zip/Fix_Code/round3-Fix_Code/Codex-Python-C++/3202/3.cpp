int f_filled(int *nums, int k) {
    vector<vector<int>> f(k, vector<int>(k, 0));
    int ans = 0;
    for (int i = 0; i < numsSize; ++i) { // Patch
        int x = nums[i] % k;
        if (x < 0) x += k;
        for (int j = 0; j < k; ++j) {
            int y = (j - x + k) % k;
            f[x][y] = f[y][x] + 1;
            ans = max(ans, f[x][y]);
        }
    }
    return ans;
}


