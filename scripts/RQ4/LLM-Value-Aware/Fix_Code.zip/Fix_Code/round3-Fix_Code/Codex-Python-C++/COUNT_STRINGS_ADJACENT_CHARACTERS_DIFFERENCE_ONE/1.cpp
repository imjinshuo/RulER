int f_filled ( int n ) {
    vector<vector<int>> dp(n + 1, vector<int>(27, 0)); // Patch
    for (int i = 0; i <= n; i++) { // Patch
        for (int j = 0; j < 27; j++) { // Patch
            dp[i][j] = 0; // Patch
        } // Patch
    } // Patch
        for ( int i = 0 ; i < 26 ; i ++ ) {
            dp [ 1 ] [ i ] = 1 ;
        }
        for ( int i = 2 ; i < n + 1 ; i ++ ) {
            for ( int j = 0 ; j < 26 ; j ++ ) {
                if ( j == 0 ) {
                    dp [ i ] [ j ] = dp [ i - 1 ] [ j + 1 ] ;
                } else {
                    dp [ i ] [ j ] = ( dp [ i - 1 ] [ j - 1 ] + dp [ i - 1 ] [ j + 1 ] ) ;
                }
            }
        }
        int sum = 0 ;
        for ( int i = 0 ; i < 26 ; i ++ ) {
            sum = sum + dp [ n ] [ i ] ;
        }
        return sum ;
    }




