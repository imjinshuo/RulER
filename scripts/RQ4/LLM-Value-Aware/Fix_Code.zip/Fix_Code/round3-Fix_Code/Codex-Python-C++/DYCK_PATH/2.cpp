int f_filled ( int n ) {
    long long res = 1; // Patch
        for ( int i = 0; i < n; i++ ) {
            res *= ( 2 * n - i );
            res /= ( i + 1 );
        }
        return res / ( n + 1 );
    }




