int f_filled ( int n ) {
    std::vector<std::vector<int>> dp(n + 1, std::vector<int>(10, 0)); // Patch
        
        if ( n == 1 ) {
            return 10;
        }
        
        for ( int j = 0; j < 10; j++ ) {
            dp [ 1 ] [ j ] = 1;
        }
        
        for ( int i = 2; i < n + 1; i++ ) {
            for ( int j = 0; j < 10; j++ ) {
                if ( j == 0 ) {
                    dp [ i ] [ j ] = dp [ i - 1 ] [ j + 1 ];
                }
                
                else if ( j == 9 ) {
                    dp [ i ] [ j ] = dp [ i - 1 ] [ j - 1 ];
                }
                
                else {
                    dp [ i ] [ j ] = ( dp [ i - 1 ] [ j - 1 ] + dp [ i - 1 ] [ j + 1 ] );
                }
            }
        }
        
        int sum = 0;
        
        for ( int j = 1; j < 10; j++ ) {
            sum = sum + dp [ n ] [ j ];
        }
        
        return sum;
    }




