int f_filled ( int n, int m ) {
    std::vector<std::vector<int>> dp(n + 1, std::vector<int>(m + 1, 0)); // Patch
    for ( int i = 1 ;
    i <= n ;
    i ++ ) {
        for ( int j = 0 ;
        j <= m ;
        j ++ ) {
            if ( i > j ) {
                if ( j == 0 ) {
                    dp [ i ] [ j ] = 1 ;
                } else {
                    dp [ i ] [ j ] = ( ( ( i - j ) * dp [ i - 1 ] [ j - 1 ] ) + ( ( j + 1 ) * dp [ i - 1 ] [ j ] ) ) ;
                }
            }
        }
    }
    return dp [ n ] [ m ] ;
    }




