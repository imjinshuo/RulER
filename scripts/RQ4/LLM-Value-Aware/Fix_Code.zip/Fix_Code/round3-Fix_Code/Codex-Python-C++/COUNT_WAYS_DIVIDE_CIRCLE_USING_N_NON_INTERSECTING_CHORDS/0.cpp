int f_filled ( int A ) {
    int n = 2 * A ;
    int* dpArray = new int[n + 1]; // Patch
    for (int k = 0; k <= n; k++) { // Patch
        dpArray[k] = 0; // Patch
    } // Patch
    dpArray [ 0 ] = 1 ;
    dpArray [ 2 ] = 1 ;
    for ( int i = 4 ; i <= n ; i += 2 ) {
        for ( int j = 0 ; j < i - 1 ; j += 2 ) {
            dpArray [ i ] += ( dpArray [ j ] * dpArray [ i - 2 - j ] ) ;
        }
    }
    return dpArray [ n ] ;
    }




