int f_filled(int *nums, int k) {
    int x = nums[0];
    // Assuming there's a way to know the number of elements, replace `n` with the actual size.
    // For demonstration purposes, let's assume we have access to `n`.
    int n = 0; // Placeholder for actual number of elements
    for (int i = 0; i < n; ++i) {
        x = std::max(x, nums[i]);
    }
    int result = k * x + k * (k - 1) / 2; // Patch
    return result; // Patch
}


