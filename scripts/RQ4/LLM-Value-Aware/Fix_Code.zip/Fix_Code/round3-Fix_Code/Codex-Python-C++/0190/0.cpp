int f_filled(int n) {
    unsigned int num = static_cast<unsigned int>(n);
    unsigned int ans = 0;
    for (int i = 0; i < 32; ++i) {
        ans |= (num & 1u) << (31 - i);
        num >>= 1;
    }
    return ans; // Patch
}


