int f_filled ( int arr [ ], int low, int high ) {
        int max = arr [ low ] ;
        int i = low ;
    for (i = low; i <= high; i++) { // Patch
            if ( arr [ i ] > max ) {
                max = arr [ i ] ;
            }
        }
        return max ;
    }




