bool f_filled ( string text , string s ) {
  string cs1 = text ;
    sort(cs1.begin(), cs1.end()); // Patch
    string cs2 = s; // Patch
    sort(cs2.begin(), cs2.end()); // Patch
  return equal ( cs1 . begin ( ) , cs1 . end ( ) , cs2 . begin ( ) ) || equal ( cs1 . begin ( ) , cs1 . end ( ) , cs2 . begin ( ) ) ;
}



