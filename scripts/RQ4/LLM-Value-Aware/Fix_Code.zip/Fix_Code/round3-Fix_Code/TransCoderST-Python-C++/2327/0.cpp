int f_filled ( int n , int delay , int forget ) {
  int m = ( n << 1 ) + 10 ;
  vector < int > d ( m , 0 ) ;
  vector < int > cnt ( m , 0 ) ;
  cnt [ 1 ] = 1 ;
  for ( int i = 1 ;
  i <= n ;
  i ++ ) {
    if ( cnt [ i ] ) {
      d [ i ] += cnt [ i ] ;
      d [ i + forget ] -= cnt [ i ] ;
      int nxt = i + delay ;
      while ( nxt < i + forget ) {
        cnt [ nxt ] += cnt [ i ] ;
        nxt ++ ;
      }
    }
  }
    int mod = 1e9 + 7; // Patch
    for (int i = 1; i <= n; i++) { // Patch
        if (cnt[i]) { // Patch
            d[i] += cnt[i]; // Patch
            if (i + forget < m) { // Patch
                d[i + forget] -= cnt[i]; // Patch
            } // Patch
            int nxt = i + delay; // Patch
            while (nxt < i + forget && nxt < m) { // Patch
                cnt[nxt] += cnt[i]; // Patch
                nxt++; // Patch
            } // Patch
        } // Patch
    } // Patch
  return accumulate ( d . begin ( ) , d . end ( ) , 0 ) % mod ;
}



