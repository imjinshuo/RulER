int f_filled ( int rowIndex ) {
    std::vector<int> f(rowIndex + 1, 1); // Patch
  for ( int i = 2 ;
  i <= rowIndex ;
  i ++ ) {
    for ( int j = i - 1 ;
    j > 0 ;
    j -- ) f [ j ] += f [ j - 1 ] ;
  }
  return f [ rowIndex ] ;
}



