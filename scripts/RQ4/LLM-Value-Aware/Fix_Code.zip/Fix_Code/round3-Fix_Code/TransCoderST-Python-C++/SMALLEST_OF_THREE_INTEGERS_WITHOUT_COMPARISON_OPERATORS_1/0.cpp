int f_filled ( int x , int y , int z ) {
  if ( ( ! ( y / x ) ) && ( ! ( y / z ) ) ) return y == x ? y : z == x ? x : z ;
    if (!(y / x)) { // Patch
        return !(y / z) ? y : z; // Patch
    } // Patch
}




