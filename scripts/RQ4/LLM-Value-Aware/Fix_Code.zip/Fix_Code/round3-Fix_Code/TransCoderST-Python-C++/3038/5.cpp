int f_filled ( int * nums ) {
  int s = nums [ 0 ] + nums [ 1 ] ;
    int ans = 0, n = 5; // Assuming the length of nums is 5 as per the input example // Patch
  for ( int i = 0 ;
  i < n ;
  i += 2 ) {
    if ( i + 1 == n || nums [ i ] + nums [ i + 1 ] != s ) break ;
    ans ++ ;
  }
  return ans ;
}



