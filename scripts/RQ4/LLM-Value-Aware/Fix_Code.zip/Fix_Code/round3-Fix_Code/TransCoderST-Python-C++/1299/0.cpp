int f_filled ( int * arr ) throw ( ) {
  int mx = - 1 ;
  for ( int i = 0 ;
  i < sizeof ( arr ) / sizeof ( int ) ;
  i ++ ) {
    int x = arr [ i ] ;
    arr[i] = mx; // Patch
    mx = max ( mx , x ) ;
  }
  return mx ;
}



