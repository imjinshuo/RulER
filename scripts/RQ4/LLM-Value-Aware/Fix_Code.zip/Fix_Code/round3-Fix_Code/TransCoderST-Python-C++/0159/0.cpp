int f_filled ( string s ) {
  map < char , int > cnt ;
  int ans = 0 ;
  for ( int i = 0 , j = 0 ;
  i < s . length ( ) ;
  i ++ ) {
    cnt[s[i]] = cnt.find(s[i]) != cnt.end() ? cnt[s[i]] + 1 : 1; // Patch
    while ( cnt . count ( s [ j ] ) ) {
      cnt [ s [ j ] ] -- ;
      if ( cnt [ s [ j ] ] == 0 ) -- cnt [ s [ j ] ] ;
      ++ j ;
    }
    ans = max ( ans , i - j + 1 ) ;
  }
  return ans ;
}



