int f_filled ( int arr [ ] , int n ) {
    int jumps[n]; // Patch
    for (int i = 0; i < n; i++) { // Patch
        jumps[i] = 0; // Patch
    } // Patch
    for (int i = 0; i < n; i++) { // Patch
        jumps[i] = 0; // Patch
    } // Patch
    for (int i = n - 2; i >= 0; i--) { // Patch
        if (arr[i] == 0) { // Patch
            jumps[i] = INT_MAX; // Patch
        } else if (arr[i] >= n - i - 1) { // Patch
            jumps[i] = 1; // Patch
        } else { // Patch
            int min = INT_MAX; // Patch
            for (int j = i + 1; j < n; j++) { // Patch
                if (j <= arr[i] + i) { // Patch
                    if (min > jumps[j]) { // Patch
                        min = jumps[j]; // Patch
                    } // Patch
                } // Patch
            } // Patch
            if (min != INT_MAX) { // Patch
                jumps[i] = min + 1; // Patch
            } else { // Patch
                jumps[i] = min; // Patch
            } // Patch
        } // Patch
    } // Patch
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ( arr [ i ] == 0 ) && ( arr [ i ] >= n - i - 1 ) ) {
      jumps [ i ] = INT_MAX ;
    }
    else {
      int min = INT_MAX ;
      for ( int j = i + 1 ;
      j < n ;
      j ++ ) {
        if ( ( arr [ i ] <= arr [ i ] + i ) && ( min > jumps [ j ] ) ) {
          min = jumps [ j ] ;
        }
      }
      if ( min != INT_MAX ) {
        jumps [ i ] = min + 1 ;
      }
      else {
        jumps [ i ] = min ;
      }
    }
  }
  return jumps [ 0 ] ;
}




