int f_filled ( int n , int k ) {
    const int mod = 1000000007; // Patch
  vector < vector < int >> f ( n + 1 , vector < int > ( k + 1 , 0 ) ) ;
  vector < vector < int >> g ( n + 1 , vector < int > ( k + 1 , 0 ) ) ;
  f [ 1 ] [ 0 ] = 1 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) {
    for ( int j = 0 ;
    j < k + 1 ;
    j ++ ) {
      f [ i ] [ j ] = ( f [ i - 1 ] [ j ] + g [ i - 1 ] [ j ] ) % mod ;
      g [ i ] [ j ] = g [ i - 1 ] [ j ] ;
      if ( j ) {
        g [ i ] [ j ] += f [ i - 1 ] [ j - 1 ] ;
        g [ i ] [ j ] %= mod ;
        g [ i ] [ j ] += g [ i - 1 ] [ j - 1 ] ;
        g [ i ] [ j ] %= mod ;
      }
    }
  }
  return ( f [ n - 1 ] [ n - 1 ] + g [ n - 1 ] [ n - 1 ] ) % mod ;
}



