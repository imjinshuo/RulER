int f_filled ( int heights [ ] ) throw ( ) {
  sort ( heights , heights + sizeof ( heights ) / sizeof ( int ) ) ;
  int pre = 0 ;
    int l = 0, r = sizeof(heights) / sizeof(heights[0]) - 1; // Patch
  int ans = 0 ;
  while ( l < r ) {
    ans += ( heights [ r ] - pre ) * ( heights [ l ] - heights [ r ] ) ;
    ans += ( heights [ l ] - heights [ r ] ) * ( heights [ l ] - heights [ r ] ) ;
    pre = heights [ l ] ;
    l = l + 1 ;
    r = r - 1 ;
  }
  ans += ( heights [ r ] - pre ) * ( heights [ r ] - pre ) ;
  return ans ;
}



