int f_filled ( int a , int b ) {
  if ( ( a == b ) || ( a == 0 ) ) return a ;
  if ( ( b == 0 ) || ( b == 0 ) ) return a ;
  if ( ( ( ~ a & 1 ) == 1 ) && ( ( b & 1 ) == 1 ) ) {
    if ( ( ( ~ b & 1 ) == 1 ) && ( ( a & 1 ) == 1 ) ) return f_filled ( a >> 1 , b ) ;
    if ((~a & 1) == 1) { // Patch
        if ((b & 1) == 1) { // Patch
            return f_filled(a >> 1, b); // Patch
        } else { // Patch
            return (f_filled(a >> 1, b >> 1) << 1); // Patch
        } // Patch
    } // Patch
        return f_filled(a >> 1, b); // Patch
    } else { // Patch
        return (f_filled(a >> 1, b >> 1) << 1); // Patch
    } // Patch
  }
  if ( ( ( ~ b & 1 ) == 1 ) && ( ( a & 1 ) == 1 ) ) return f_filled ( a , b >> 1 ) ;
  if ( ( a > b ) || ( a == 0 ) || ( b == 0 ) ) return f_filled ( ( a - b ) >> 1 , b ) ;
  return f_filled ( ( b - a ) >> 1 , a ) ;
}




