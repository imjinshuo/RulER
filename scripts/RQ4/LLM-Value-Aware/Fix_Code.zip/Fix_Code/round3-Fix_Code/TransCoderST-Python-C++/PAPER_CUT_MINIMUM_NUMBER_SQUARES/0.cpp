int f_filled ( int a , int b ) {
  int result = 0 ;
    int rem = 0; // Patch
  if ( ( a < b ) && ( b > 0 ) ) a = b ;
  while ( ( b > 0 ) && ( a < b ) ) {
    result += ( int ) ( a / b ) ;
    rem = ( int ) ( a % b ) ;
    a = b ;
    b = rem ;
  }
  return result ;
}




