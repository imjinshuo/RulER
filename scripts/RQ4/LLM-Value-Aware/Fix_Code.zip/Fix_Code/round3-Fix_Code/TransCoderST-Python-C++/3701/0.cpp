int f_filled ( int * nums ) {
    int sumEven = 0, sumOdd = 0; // Patch
    for (int i = 0; i < sizeof(nums) / sizeof(nums[0]); i++) { // Patch
        if (i % 2 == 0) { // Patch
            sumEven += nums[i]; // Patch
        } else { // Patch
            sumOdd += nums[i]; // Patch
        } // Patch
    } // Patch
    return sumEven - sumOdd; // Patch
}



