int f_filled ( int * nums ) {
    int n = sizeof(nums) / sizeof(nums[0]); // Patch
    int l0 = 0, r1 = 0; // Patch
    for (int i = 0; i < n; i++) { // Patch
        r1 += nums[i]; // Patch
    } // Patch
    int l0 = 0, r1 = 0; // Patch
    for (int i = 0; i < n; i++) { // Patch
    r1 = 0; // Patch
    for (int i = 0; i < n; i++) { // Patch
        r1 += nums[i]; // Patch
    } // Patch
    } // Patch
  int mx = r1 ;
  int ans [ 1 ] ;
  for ( int i = 0 , x = 0 ;
  i < nums [ 0 ] ;
  i ++ , x ++ ) {
    l0 += x ^ 1 ;
    r1 -= x ;
    int t = l0 + r1 ;
    if ( mx == t ) ans [ 0 ] = i ;
    else if ( mx < t ) {
      mx = t ;
      ans [ 0 ] = i ;
    }
  }
  return ans [ 0 ] ;
}



