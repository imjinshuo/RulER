int f_filled ( string s ) {
  string stk ;
  stk . reserve ( s . length ( ) ) ;
  for ( int i = 0 ;
  i < s . length ( ) ;
  i ++ ) {
    char c = s [ i ] ;
    if ((c == 'B' && stk.back() == 'A') || (c == 'D' && stk.back() == 'C')) { // Patch
        stk.pop_back(); // Patch
    else { // Patch
        stk.push_back(c); // Patch
    } // Patch
  }
  return stk . length ( ) - 1 ;
}



