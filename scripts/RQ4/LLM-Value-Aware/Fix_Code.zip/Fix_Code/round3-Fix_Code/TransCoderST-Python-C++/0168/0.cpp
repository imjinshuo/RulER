string f_filled ( int columnNumber ) throw ( ) {
  string res ;
  while ( columnNumber ) {
    columnNumber -- ;
    res += ( char ) ( 'A' + columnNumber % 26 ) ;
    columnNumber /= 26 ;
  }
    reverse(res.begin(), res.end()); // Patch
}



