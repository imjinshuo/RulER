int f_filled ( int x , int y , int bound ) {
    std::set<int> ans; // Patch
  int a = 1 ;
  while ( a <= bound ) {
    int b = 1 ;
    while ( a + b <= bound ) {
      ans . insert ( a + b ) ;
      b *= y ;
      if ( y == 1 ) break ;
    }
    if ( x == 1 ) break ;
    a *= x ;
  }
  return ans . size ( ) ;
}



