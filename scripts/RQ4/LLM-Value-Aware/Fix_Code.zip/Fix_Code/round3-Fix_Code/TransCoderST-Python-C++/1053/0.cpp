int f_filled ( int * arr ) {
    int n = sizeof(arr) / sizeof(arr[0]); // Patch
  for ( int i = n - 1 ;
  i > 0 ;
  i -- ) {
    if ( arr [ i - 1 ] > arr [ i ] ) {
      for ( int j = n - 1 ;
      j > i - 1 ;
      j -- ) {
        if ( arr [ j ] < arr [ i - 1 ] && arr [ j ] != arr [ j - 1 ] ) {
          arr [ i - 1 ] = arr [ j ] ;
          arr [ i - 1 ] = arr [ i - 1 ] ;
          return i ;
        }
      }
    }
  }
  return n ;
}



