int f_filled ( int n ) {
    int* BT = new int[n + 1]; // Patch
    for (int k = 0; k <= n; k++) { // Patch
        BT[k] = 0; // Patch
    } // Patch
  BT [ 0 ] = BT [ 1 ] = 1 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) {
    for ( int j = 0 ;
    j < i ;
    j ++ ) BT [ i ] += BT [ j ] * BT [ i - j - 1 ] ;
  }
  return BT [ n ] ;
}




