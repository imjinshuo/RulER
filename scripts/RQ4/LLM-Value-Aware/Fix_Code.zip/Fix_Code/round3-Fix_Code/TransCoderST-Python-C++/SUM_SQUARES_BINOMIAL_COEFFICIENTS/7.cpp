int f_filled ( int n ) {
    std::vector<std::vector<int>> C(n + 1, std::vector<int>(n + 1, 0)); // Patch
    for (int i = 0; i <= n; i++) { // Patch
        for (int j = 0; j <= n; j++) { // Patch
            C[i][j] = 0; // Patch
        } // Patch
    } // Patch
  for ( int j = 0 ;
  j <= n ;
  j ++ ) {
    for ( int i = 0 ;
    i <= n ;
    i ++ ) {
      if ( ( j == 0 || j == i ) && ( C [ i ] [ j ] == 0 ) ) C [ i ] [ j ] = 1 ;
      else C [ i ] [ j ] = ( C [ i - 1 ] [ j - 1 ] + C [ i - 1 ] [ j ] ) ;
    }
  }
  int sum = 0 ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) sum = sum + ( C [ n ] [ i ] * C [ n ] [ i ] ) ;
  return sum ;
}




