int f_filled ( string seq ) {
    vector<int> ans(seq.length()); // Patch
  int x = 0 ;
  for ( int i = 0 , n = seq . length ( ) ;
  i < n ;
  i ++ ) {
    char c = seq [ i ] ;
    if ( c == '(' ) {
      ans [ i ] = x & 1 ;
      x ++ ;
    }
    else {
      x -- ;
      ans [ i ] = x & 1 ;
    }
  }
  return ans [ seq . length ( ) - 1 ] ;
}



