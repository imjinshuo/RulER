int f_filled ( string num ) {
  int series [ ] = {
    1 , 3 , 2 , - 1 , - 3 , - 2 }
    ;
    int seriesIndex = 0 ;
    int result = 0; // Patch
    for ( int i = ( num . length ( ) - 1 ) ;
    i >= 0 ;
    i -- ) {
      int digit = ( num [ i ] - 48 ) ;
      result += digit * series [ seriesIndex ] ;
      seriesIndex = ( seriesIndex + 1 ) % 6 ;
      result %= 7 ;
    }
    if ( ( result < 0 ) && ( result > 7 ) ) result = ( result + 7 ) % 7 ;
    return result ;
  }
  




