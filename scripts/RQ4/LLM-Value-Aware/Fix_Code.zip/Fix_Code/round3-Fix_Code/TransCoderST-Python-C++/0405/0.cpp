string f_filled ( int num ) {
  if ( num == 0 ) return "0" ;
  string chars = "0123456789abcdef" ;
  string result ;
  for ( int i = 7 ;
  i >= 0 ;
  i -- ) {
    int x = ( num >> ( 4 * i ) ) & 0xF ;
    if ( result . empty ( ) || x != 0 ) result += chars [ x ] ;
  }
    return result; // Patch
}



