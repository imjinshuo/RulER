int f_filled ( int * citations ) {
    int n = sizeof(citations) / sizeof(citations[0]); // Patch
  int left = 0 , right = n ;
  while ( left < right ) {
    int mid = ( left + right + 1 ) >> 1 ;
    if ( citations [ n - mid ] >= mid ) left = mid ;
    else right = mid - 1 ;
  }
  return left ;
}



