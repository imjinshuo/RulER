bool f_filled ( int n ) {
  int k = to_string ( n ) . length ( ) ;
  int s = 0 , x = n ;
    while (x) { // Patch
    s += ( x % 10 ) * k ;
    x /= 10 ;
  }
  return s == n ;
}



