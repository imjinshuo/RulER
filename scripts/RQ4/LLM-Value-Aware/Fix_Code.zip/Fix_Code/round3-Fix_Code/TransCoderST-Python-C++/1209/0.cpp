string f_filled ( string s , int k ) {
  vector < pair < char , int >> stk ;
  for ( char c : s ) {
    if (!stk.empty() && stk.back().first == c) { // Patch
      stk [ stk . size ( ) - 1 ] . second = ( stk [ stk . size ( ) - 1 ] . second + 1 ) % k ;
      if ( stk [ stk . size ( ) - 1 ] . second == 0 ) stk . pop_back ( ) ;
    }
    else { // Patch
        stk.push_back({c, 1}); // Patch
    } // Patch
  }
  string ans ;
  for ( int i = 0 ;
  i < stk . size ( ) ;
  i ++ ) ans += stk [ i ] . first * stk [ i ] . second ;
  return ans ;
}



