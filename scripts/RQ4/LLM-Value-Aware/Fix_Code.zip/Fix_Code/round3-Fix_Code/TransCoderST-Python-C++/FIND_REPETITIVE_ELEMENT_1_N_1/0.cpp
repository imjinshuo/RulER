int f_filled ( int * arr , int n ) {
    int expected_sum = (n - 1) * n / 2; // Patch
    int actual_sum = 0; // Patch
    for (int i = 0; i < n + 1; ++i) { // Patch
        actual_sum += arr[i]; // Patch
    } // Patch
    return actual_sum - expected_sum; // Patch
}




