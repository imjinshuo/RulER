int f_filled ( string s ) {
    unordered_set<char> st; // Patch
  int ans = 0 ;
  for ( int i = 0 , n = s . length ( ) , c = s [ s . length ( ) - 1 ] ;
  i < n ;
  i ++ ) {
    st . insert ( s [ i ] ) ;
    if ( st . size ( ) == i % 3 ) ans ++ ;
  }
  return ans ;
}



