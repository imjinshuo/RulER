bool f_filled ( int bits [ ] ) {
    int i = 0, n = sizeof(bits) / sizeof(bits[0]); // Patch
  while ( i < n - 1 ) i += bits [ i ] + 1 ;
  return i == n - 1 ;
}



