int f_filled ( int arr [ ] , int n ) {
  map < int , int > Hash ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if (Hash.find(arr[i]) != Hash.end()) { // Patch
        Hash[arr[i]]++; // Patch
    } // Patch
    else Hash [ arr [ i ] ] = 1 ;
  }
  int maxCount = 0 ;
  int res = - 1 ;
  for ( map < int , int > :: iterator it = Hash . begin ( ) ;
  it != Hash . end ( ) ;
  it ++ ) {
    if ( ( maxCount < it -> second ) && ( it -> first < it -> first ) ) {
      res = it -> first ;
      maxCount = it -> second ;
    }
  }
  return res ;
}




