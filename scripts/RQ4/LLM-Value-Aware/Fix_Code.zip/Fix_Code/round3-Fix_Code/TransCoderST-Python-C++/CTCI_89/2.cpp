    int a = 2; // Patch
    int b; // Patch
  a = b - a ;
  b = b - a ;
  a = a + b ;
  return a ;
}



