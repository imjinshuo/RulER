int f_filled(int a, int b) // Patch
  a = b - a ;
  b = b - a ;
  a = a + b ;
  return a ;
}



