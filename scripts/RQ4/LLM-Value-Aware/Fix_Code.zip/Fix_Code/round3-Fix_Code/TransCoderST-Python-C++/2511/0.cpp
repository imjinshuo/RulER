int f_filled ( int * forts ) {
    int n = sizeof(forts) / sizeof(forts[0]); // Patch
  int i = 0 , ans = 0 ;
  while ( i < n ) {
    int j = i + 1 ;
    if ( forts [ i ] ) {
      while ( j < n && forts [ j ] == 0 ) j ++ ;
      if ( j < n && forts [ i ] + forts [ j ] == 0 ) ans = max ( ans , j - i - 1 ) ;
    }
    i = j ;
  }
  return ans ;
}



