string f_filled ( string text , string s ) {
  int m = text . length ( ) , n = s . length ( ) ;
  vector < vector < int >> f ( m + 1 , vector < int > ( n + 1 , 0 ) ) ;
    for (int i = 1;  // Patch
  i <= m ;
  i ++ ) {
    for ( int j = 1 ;
    j <= n ;
    j ++ ) {
      if ( text [ i - 1 ] == s [ j - 1 ] ) f [ i ] [ j ] = f [ i - 1 ] [ j - 1 ] + 1 ;
      else f [ i ] [ j ] = max ( f [ i - 1 ] [ j ] , f [ i ] [ j - 1 ] ) ;
    }
  }
  string ans ;
  int i = m , j = n ;
  while ( i || j ) {
    if ( i == 0 ) {
      j -- ;
      ans += s [ j ] ;
    }
    else if ( j == 0 ) {
      i -- ;
      ans += text [ i ] ;
    }
    else {
      if ( f [ i ] [ j ] == f [ i - 1 ] [ j ] ) {
        i -- ;
        ans += text [ i ] ;
      }
      else if ( f [ i ] [ j ] == f [ i ] [ j - 1 ] ) {
        j -- ;
        ans += s [ j ] ;
      }
      else {
        i = i - 1 ;
        j = j - 1 ;
        ans += text [ i ] ;
      }
    }
  }
  return ans . substr ( 0 , ans . length ( ) - 1 ) ;
}



