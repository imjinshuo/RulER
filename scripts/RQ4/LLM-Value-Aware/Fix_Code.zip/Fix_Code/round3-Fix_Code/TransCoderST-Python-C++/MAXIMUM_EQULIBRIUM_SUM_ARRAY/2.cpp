int f_filled ( int * arr , int n ) {
    int res = -2147483648; // This should be the minimum possible integer value, equivalent to -sys.maxsize - 1 in Python // Patch
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int prefixSum = arr [ i ] ;
    for ( int j = 0 ;
    j < i ;
    j ++ ) prefixSum += arr [ j ] ;
    int suffixSum = arr [ i ] ;
    int j = n - 1 ;
    while ( ( j > i ) && ( prefixSum == suffixSum ) ) {
      suffixSum += arr [ j ] ;
      j -- ;
    }
    if ( ( prefixSum == suffixSum ) || ( suffixSum == i ) ) res = max ( res , prefixSum ) ;
  }
  return res ;
}




