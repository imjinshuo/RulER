int f_filled ( int num ) {
    int x = num / 3; // Patch
    int mod = num % 3; // Patch
    int mod = num % 3; // Patch
    x = num / 3; // Patch
    mod = num % 3; // Patch
  mod = num % 3 ;
  x = mod ? x - 1 : x ;
  return mod == 0 ? 0 : x ;
}



