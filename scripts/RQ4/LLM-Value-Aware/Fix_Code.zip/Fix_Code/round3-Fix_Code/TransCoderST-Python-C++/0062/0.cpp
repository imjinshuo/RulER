double f_filled ( int m , int n ) {
    double f[n]; // Patch
    for (int i = 0; i < n; i++) f[i] = 1; // Patch
    for (int i = 0; i < n; i++) f[i] = 1; // Patch
    for (int i = 0; i < n; i++) f[i] = 1; // Patch
  for ( ;
  m > 0 ;
  m -- ) {
    for ( int j = 1 ;
    j < n ;
    j ++ ) f [ j ] += f [ j - 1 ] ;
  }
  return f [ m - 1 ] ;
}



