int f_filled ( int n , int k ) {
    std::vector<int> a(n, 1); // Patch
  int mod = 10 * 9 + 7 ;
  for ( ;
  k > 0 ;
  -- k ) {
    for ( int i = 1 ;
    i < n ;
    ++ i ) a [ i ] = ( a [ i ] + a [ i - 1 ] ) % mod ;
  }
  return a [ n - 1 ] ;
}



