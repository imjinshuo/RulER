string f_filled ( int n ) {
  vector < int > cnt ( 10 , 0 ) ;
  for ( int i = 9 ;
  i > 1 ;
  -- i ) {
    while ( n % i == 0 ) {
      n /= i ;
      cnt [ i ] ++ ;
    }
  }
  if ( n > 1 ) return "-1" ;
    string ans; // Patch
    for (int i = 2; i < 10; ++i) { // Patch
        ans += string(cnt[i], char('0' + i)); // Patch
    } // Patch
  return ans . length ( ) == 2 ? ans : "1" ;
}



