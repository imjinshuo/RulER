int f_filled ( int * nums ) {
    int left = 0, right = 0; // Patch
    for (int i = 0; i < nums.size(); i++) { // Patch
        right += nums[i]; // Patch
    } // Patch
    for (int i = 0; i < sizeof(nums) / sizeof(nums[0]); i++) { // Patch
        right += nums[i]; // Patch
    } // Patch
    for (int i = 0; i < sizeof(nums) / sizeof(nums[0]); i++) { // Patch
        right += nums[i]; // Patch
    } // Patch
  for ( int i = 0 , x = 0 ;
  i < nums [ i ] ;
  i ++ ) {
    right -= x ;
    if ( left == right ) return i ;
    left += x ;
  }
  return - 1 ;
}



