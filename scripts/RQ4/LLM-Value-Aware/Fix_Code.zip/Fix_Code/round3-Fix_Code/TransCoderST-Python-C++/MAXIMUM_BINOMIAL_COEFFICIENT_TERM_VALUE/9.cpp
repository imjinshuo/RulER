int f_filled ( int n ) {
    std::vector<std::vector<int>> C(n + 1, std::vector<int>(n + 1, 0)); // Patch
  for ( int y = 0 ;
  y < n + 1 ;
  y ++ ) {
    for ( int i = 0 ;
    i < n + 1 ;
    i ++ ) {
      for ( int j = 0 ;
      j < min ( i , n ) + 1 ;
      j ++ ) {
        if ( ( j == 0 || j == i ) && ( C [ i ] [ j ] == 1 ) ) C [ i ] [ j ] = 1 ;
        else C [ i ] [ j ] = ( C [ i - 1 ] [ j - 1 ] + C [ i - 1 ] [ j ] ) ;
      }
    }
  }
  int maxvalue = 0 ;
  for ( int i = 0 ;
  i < n + 1 ;
  i ++ ) maxvalue = max ( maxvalue , C [ n ] [ i ] ) ;
  return maxvalue ;
}




