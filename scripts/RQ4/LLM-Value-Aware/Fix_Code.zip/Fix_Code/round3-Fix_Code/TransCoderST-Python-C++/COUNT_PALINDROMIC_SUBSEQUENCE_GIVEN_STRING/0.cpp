int f_filled ( string str ) {
  int N = str . length ( ) ;
    vector<vector<int>> cps(N + 2, vector<int>(N + 2, 0)); // Patch
  for ( int j = 0 ;
  j < N + 2 ;
  j ++ ) {
    for ( int i = 0 ;
    i < N ;
    i ++ ) {
      cps [ i ] [ i ] = 1 ;
    }
  }
  for ( int L = 2 ;
  L <= N ;
  L ++ ) {
    for ( int i = 0 ;
    i < N ;
    i ++ ) {
      int k = L + i - 1 ;
      if ( ( k < N ) && ( str [ i ] == str [ k ] ) ) {
        cps [ i ] [ k ] = ( cps [ i ] [ k - 1 ] + cps [ i + 1 ] [ k ] + 1 ) ;
      }
      else {
        cps [ i ] [ k ] = ( cps [ i ] [ k - 1 ] + cps [ i + 1 ] [ k ] - cps [ i + 1 ] [ k - 1 ] ) ;
      }
    }
  }
  return cps [ 0 ] [ N - 1 ] ;
}




