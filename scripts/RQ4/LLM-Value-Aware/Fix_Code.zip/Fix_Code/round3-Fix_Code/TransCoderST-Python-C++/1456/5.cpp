int f_filled ( string s , int k ) {
    set<char> vowels = {'a', 'e', 'i', 'o', 'u'}; // Patch
  int ans = 0 ;
  int cnt = 0 ;
  for ( int i = k ;
  i < s . length ( ) ;
  i ++ ) {
    cnt += vowels . find ( s [ i ] ) != string :: npos ? vowels . length ( ) - vowels . find ( s [ i - k ] ) : vowels . length ( ) ;
    ans = max ( ans , cnt ) ;
  }
  return ans ;
}



