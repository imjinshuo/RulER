string f_filled ( string s ) throw ( ) {
  string result ;
  int n = s . length ( ) ;
  for ( int i = 0 ;
    for (int i = 0; i < n; i++) // Patch
  i ++ ) {
    if ( s [ i ] == '?' ) {
      for ( char c : " abc " ) {
        if ( ( i > 0 && s [ i - 1 ] == c ) || ( i + 1 < n && s [ i + 1 ] == c ) ) continue ;
        result += c ;
        break ;
      }
    }
  }
    for (int i = 0; i < n; i++) { // Patch
        if (s[i] == '?') { // Patch
            for (char c : {'a', 'b', 'c'}) { // Patch
                if ((i > 0 && s[i - 1] == c) || (i + 1 < n && s[i + 1] == c)) continue; // Patch
                s[i] = c; // Patch
                break; // Patch
            } // Patch
        } // Patch
    } // Patch
    for (int i = 0; i < n; i++) { // Patch
        if (s[i] == '?') { // Patch
            for (char c : {'a', 'b', 'c'}) { // Patch
                if ((i > 0 && s[i - 1] == c) || (i + 1 < n && s[i + 1] == c)) continue; // Patch
                result[i] = c; // Patch
                break; // Patch
            } // Patch
        } // Patch
    } // Patch
}



