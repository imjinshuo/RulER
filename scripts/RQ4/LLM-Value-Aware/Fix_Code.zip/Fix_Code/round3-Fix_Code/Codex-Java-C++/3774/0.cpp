int f_filled(int *nums, int k) {
    vector<int> arr(nums, nums + k);
    sort(arr.begin(), arr.end());
    int ans = 0;
    int n = sizeof(nums) / sizeof(nums[0]); // Patch
    for (int i = 0; i < k; ++i) {
        ans += arr[n - i - 1] - arr[i];
    }
    return ans;
}


