int f_filled(int *arr, int k) {
    unordered_map<int, int> cnt;
    for (int i = 0; arr[i]; ++i) {
        cnt[arr[i]] += 1;
    }
    vector<int> nums;
    for (const auto& p : cnt) { // Patch
        nums.push_back(p.second);
    }
    sort(nums.begin(), nums.end());
    for (int i = 0, m = nums.size(); i < m; ++i) {
        k -= nums[i];
        if (k < 0) {
            return m - i;
        }
    }
    return 0;
}


