long long f_filled(int* nums, int n) {
    std::vector<int> stk;
    for (int idx = 0; idx < n; ++idx) {
        while (!stk.empty() && nums[stk.back()] <= nums[idx]) {
            stk.pop_back();
        }
    stk.push_back(idx); // Patch
    }
    long long ans = 0, i = 0;
    while (!stk.empty()) {
        int j = stk.back();
        stk.pop_back();
        ans += (j - i) * 1LL * nums[j];
        i = j;
    }
    return ans;
}


