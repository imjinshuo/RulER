int f_filled(int *nums, int dummy) {
    int n = sizeof(nums) / sizeof(nums[0]); // Patch
    sort(nums, nums + n);
    set<int> s;
    for (int i = 0; i < (n >> 1); ++i) {
        s.insert(nums[i] + nums[n - i - 1]);
    }
    return s.size();
}


