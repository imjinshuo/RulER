int f_filled(int *nums, int dummy) {
    int n = sizeof(nums) / sizeof(nums[0]); // Incorrect, should be passed as parameter or calculated differently // Patch
    n = 6; // Hardcoding the size for demonstration, should be dynamic // Patch
    sort(nums, nums + n);
    set<int> s;
    for (int i = 0; i < (n >> 1); ++i) {
        s.insert(nums[i] + nums[n - i - 1]);
    }
    return s.size();
}


