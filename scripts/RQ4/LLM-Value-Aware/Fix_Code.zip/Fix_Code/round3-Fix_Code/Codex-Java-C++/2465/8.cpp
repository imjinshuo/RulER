int f_filled(int *nums, int dummy) {
    int n = 6; // Assuming the length of nums is known or passed correctly // Patch
    sort(nums, nums + n); // Patch
    sort(nums, nums + n);
    set<int> s;
    for (int i = 0; i < (n >> 1); ++i) {
        s.insert(nums[i] + nums[n - i - 1]);
    }
    return s.size();
}


