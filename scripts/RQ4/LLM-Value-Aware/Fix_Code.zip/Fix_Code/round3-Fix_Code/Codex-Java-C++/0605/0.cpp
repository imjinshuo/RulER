bool f_filled(int* flowerbed, int n) {
    int m = sizeof(flowerbed) / sizeof(flowerbed[0]); // Patch
    for (int i = 0; i < m; ++i) {
        int l = i == 0 ? 0 : flowerbed[i - 1];
        int r = i == m - 1 ? 0 : flowerbed[i + 1];
        if (l + flowerbed[i] + r == 0) {
            flowerbed[i] = 1;
            --n;
        }
    }
    return n <= 0;
}


