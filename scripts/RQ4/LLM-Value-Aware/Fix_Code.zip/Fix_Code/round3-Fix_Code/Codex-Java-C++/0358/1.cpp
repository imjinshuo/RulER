string f_filled(string s, int k) {
    vector<int> cnt(26, 0);
    for (char c : s) {
        ++cnt[c - 'a'];
    }
    priority_queue<pair<int, int>> pq;
    for (int i = 0; i < cnt.size(); ++i) {
        if (cnt[i] > 0) {
            pq.push({cnt[i], i});
        }
    }
    deque<pair<int, int>> q;
    string ans;
    while (!pq.empty()) {
        auto p = pq.top();
        pq.pop();
        --p.first; // Patch
        ans.push_back('a' + p.second);
        q.push_back(p);
        if (q.size() >= k) {
            auto front = q.front();
            q.pop_front();
            if (front.first > 0) {
                pq.push(front);
            }
        }
    }
    return ans.size() < s.size() ? "" : ans;
}


