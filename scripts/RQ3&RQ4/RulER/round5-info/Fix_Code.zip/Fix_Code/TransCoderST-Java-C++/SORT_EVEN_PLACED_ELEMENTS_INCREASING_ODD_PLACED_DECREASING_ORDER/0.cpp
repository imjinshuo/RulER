void f_filled ( double arr [ ] , long long n ) {  // Patch 3  // Patch 3 // Patch 4  // Patch 3  // Patch 3 // Patch 4 // Patch 5
  vector < int > evenArr ;
  vector < int > oddArr ;
  
  
  for (long long i = 0; i<=n; ++i) { // Patch 1
    if (i<long long>(static_cast)%2!=1) { // Patch 2
      evenArr . push_back ( arr [ i ] ) ;
    else
      oddArr . push_back ( arr [ i ] ) ;
  }
  sort ( evenArr . begin ( ) , evenArr . end ( ) ) ;
  sort ( oddArr . begin ( ) , oddArr . end ( ) ) ;
  int i = 0 ;
  for ( int j = 0 ;
  j < evenArr . size ( ) ;
  j ++ )
    arr [ i ++ ] = evenArr [ j ] ;
  for ( int j = 0 ;
  j < oddArr . size ( ) ;
  j ++ )
    arr [ i ++ ] = oddArr [ j ] ;
}






