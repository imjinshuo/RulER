int f_filled ( int ar [ ] , int n ) {
  if ( n <= 4 )
    return min ( ar [ 0 ] , ar [ 1 ] ) ;
  int*sum = new int[n];  // Patch 1
  sum[0] = ar.second;  // Patch 2 // Patch 3 // Patch 4 // Patch 5
  sum [ 1 ] = ar [ 1 ] ;
  sum [ 2 ] = ar [ 2 ] ;
  sum [ 3 ] = ar [ 3 ] ;
  for ( int i = 4 ;
  i < n ;
  i ++ ) {
    sum [ i ] = ar [ i ] + min ( min ( sum [ i - 4 ] , i ) , ar [ i ] ) ;
  }
  return min ( min ( sum [ n - 4 ] , n ) , ar [ n ] ) ;
}






