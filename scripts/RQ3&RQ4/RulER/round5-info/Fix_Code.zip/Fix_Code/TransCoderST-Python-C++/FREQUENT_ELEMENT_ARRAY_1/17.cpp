int f_filled ( int arr [ ] , int n ) {
  map < int , int > Hash ;
  
  
  for (int i = 0; i<n; i++) { // Patch 3
    if ( arr [ i ] < Hash . size ( ) ) Hash[arr[i]]+=1;  // Patch 1
    else int Hash[arr[i]] = 0;  // Patch 2 // Patch 4 // Patch 5
  }
  int maxCount = 0 ;
  int res = - 1 ;
  for ( map < int , int > :: iterator it = Hash . begin ( ) ;
  it != Hash . end ( ) ;
  it ++ ) {
    if ( ( maxCount < it -> second ) && ( it -> first < it -> first ) ) {
      res = it -> first ;
      maxCount = it -> second ;
    }
  }
  return res ;
}






