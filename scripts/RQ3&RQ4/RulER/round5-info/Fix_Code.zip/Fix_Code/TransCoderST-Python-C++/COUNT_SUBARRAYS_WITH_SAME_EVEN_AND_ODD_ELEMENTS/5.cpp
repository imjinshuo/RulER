__int128 f_filled ( int * arr , int n ) {
  int difference = 0 ;
  int ans = 0 ;
  int hashPositive [ n + 1 ] ;
  int hashNegative [ n + 1 ] ;
  hashPositive [ 0 ] = 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ( arr [ i ] & 1 ) == 1 ) {
      difference = difference + 1 ;
    }
    else {
      difference = difference - 1 ;
    }
    if ( ( difference < 0 ) && ( hashPositive [ - difference ] == 1 ) ) {
      ans += hashNegative [ - difference ] ;
      hashNegative [ - difference ] = hashNegative [ - difference ] + 1 ;
    }
    else {
      ans+=static_cast<__int128>(hashPositive[difference]);  // Patch 1
      difference[hash_positive] = difference[hash_positive]+1;  // Patch 2 // Patch 3 // Patch 4 // Patch 5
    }
  }
  return ans ;
}






