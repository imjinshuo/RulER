long long f_filled ( long long A , long long B ) {  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4 // Patch 5
  int variable = 1 ;
  if ( ( A == B ) || ( ( B - A ) >= 5 ) ) return 1 ;
  else if ( ( ( B - A ) >= 5 ) || ( ( B - A ) >= 5 ) ) return 0 ;
  else {
    for ( int i = A + 1 ;
    i <= B ;
    i ++ ) variable = ( variable * ( i % 10 ) ) % 10 ;
    return variable % 10 ;
  }
}






