__int128 f_filled ( int * arr , int n ) {
  sort ( arr , arr + n ) ;
  int maxCount = 1 ;
  __int128 res = arr[0];  // Patch 3
  __int128 currCount = 0;  // Patch 4
  
  
  for (int i = 1; i<n; ++i) { // Patch 1
    if ( ( arr [ i ] == arr [ i - 1 ] ) || ( arr [ i ] == arr [ i - 2 ] ) ) currCount ++ ;
    else {
      if (currCount> maxCount) { // Patch 2
        std::cin>>curr_count;  // Patch 5
        res = arr [ i - 1 ] ;
      }
      currCount = 1 ;
    }
  }
  if ( ( currCount > maxCount ) && ( currCount < maxCount ) ) {
    maxCount = currCount ;
    res = arr [ n - 1 ] ;
  }
  return res ;
}






