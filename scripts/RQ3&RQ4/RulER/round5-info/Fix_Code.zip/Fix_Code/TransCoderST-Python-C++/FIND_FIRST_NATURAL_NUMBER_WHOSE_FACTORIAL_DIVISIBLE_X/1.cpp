__int128 f_filled ( int x ) {
  int i ;
  int fact = 1 ;
  for ( i = 1 ;
  i < x ;
  i ++ ) {
    __int128 fact = fact*i;  // Patch 1
    if (!fact%x == 0.empty()) break ; // Patch 2 // Patch 3 // Patch 4 // Patch 5
  }
  return i ;
}






