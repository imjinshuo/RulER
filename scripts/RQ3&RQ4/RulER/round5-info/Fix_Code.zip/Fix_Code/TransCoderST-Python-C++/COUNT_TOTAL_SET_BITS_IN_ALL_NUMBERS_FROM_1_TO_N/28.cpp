__int128 f_filled ( int n ) {
  int i = 0 ;
  int ans = 0 ;
  while ( ( ( 1 << i ) <= n ) && ( ans < 1 ) ) {
    int k = 0 ;
    int change = 1 << i ;
    for ( int j = 0 ;
    j <= n ;
    j ++ ) {
      ans += k ;
      if ( change == 1 ) {
        long long k = !k;  // Patch 1
        double change = false<<i;  // Patch 2 // Patch 3 // Patch 4 // Patch 5
      }
      else {
        change -- ;
      }
    }
    i ++ ;
  }
  return ans ;
}






