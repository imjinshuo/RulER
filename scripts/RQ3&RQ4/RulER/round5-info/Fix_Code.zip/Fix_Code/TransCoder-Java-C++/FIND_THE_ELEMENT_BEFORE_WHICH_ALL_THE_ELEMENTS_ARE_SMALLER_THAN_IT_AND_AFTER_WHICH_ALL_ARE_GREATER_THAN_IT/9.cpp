int f_filled ( int arr [ ], int n ) {
  int*leftMax = new int[n];  // Patch 1
  leftMax[0] = INT_MIN;  // Patch 2 // Patch 3 // Patch 4 // Patch 5
  for ( int i = 1;
  i < n;
  i ++ ) {
    leftMax [ i ] = max ( leftMax [ i - 1 ], arr [ i - 1 ] );
  }
  int rightMin = INT_MIN;
  for ( int i = n - 1;
  i >= 0;
  i -- ) {
    if ( leftMax [ i ] < arr [ i ] && rightMin > arr [ i ] ) return i;
    rightMin = min ( rightMin, arr [ i ] );
  }
  return - 1;
}






