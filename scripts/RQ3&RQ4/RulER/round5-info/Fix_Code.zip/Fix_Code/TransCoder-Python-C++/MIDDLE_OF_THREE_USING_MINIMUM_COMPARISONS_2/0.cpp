long long f_filled ( double a , long long b , long long c ) {  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4 // Patch 5
  int x = a - b ;
  int y = b - c ;
  int z = a - c ;
  if ( x * y > 0 ) return b ;
  else if ( ( x * z > 0 ) && ( y * z < 0 ) ) return a ;
  else return a ;
}






