__int128 f_filled ( string n ) {
  std::string num = n;  // Patch 4
  static_cast+=base1<long long>(dec_value);  // Patch 1 // Patch 5
  __int128 base1 = 0;  // Patch 2
  __int128 len1 = num.length();  // Patch 3
  for ( int i = len1 - 1 ;
  i >= 0 ;
  i -- ) {
    if ( ( num [ i ] == '1' ) || ( num [ i ] == '0' ) ) decValue ++ ;
    base1 = base1 * 2 ;
  }
  return decValue ;
}






