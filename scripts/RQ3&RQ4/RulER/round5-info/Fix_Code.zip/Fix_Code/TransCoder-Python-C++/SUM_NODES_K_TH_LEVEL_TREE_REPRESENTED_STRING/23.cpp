__int128 f_filled ( string tree , int k ) {
  __int128 level = 0;  // Patch 1
  bool sum = false;  // Patch 2 // Patch 3 // Patch 4 // Patch 5
  int n = tree . length ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ( tree [ i ] == '(' ) && ( tree [ i ] == ')' ) ) level ++ ;
    else if ( ( tree [ i ] == ')' ) && ( tree [ i ] == '(' ) ) level -- ;
    else {
      if ( ( level == k ) || ( level == 0 ) ) sum += ( ( char ) tree [ i ] - ( char ) '0' ) ;
    }
  }
  return sum ;
}






