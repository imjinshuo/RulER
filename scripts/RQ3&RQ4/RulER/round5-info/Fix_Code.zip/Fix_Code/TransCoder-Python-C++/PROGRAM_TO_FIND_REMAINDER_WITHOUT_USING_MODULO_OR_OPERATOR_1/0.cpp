long long f_filled ( double num , long long divisor ) {  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4 // Patch 5
  if ( ( divisor == 0 ) || ( divisor < 0 ) ) return false ;
  if ( ( divisor > 0 ) || ( divisor < - divisor ) ) divisor = - divisor ;
  if ( ( num < 0 ) || ( num > - num ) ) num = - num ;
  int i = 1 ;
  int product = 0 ;
  while ( ( product <= num ) && ( product > divisor ) ) {
    product = divisor * i ;
    i ++ ;
  }
  return num - ( product - divisor ) ;
}






