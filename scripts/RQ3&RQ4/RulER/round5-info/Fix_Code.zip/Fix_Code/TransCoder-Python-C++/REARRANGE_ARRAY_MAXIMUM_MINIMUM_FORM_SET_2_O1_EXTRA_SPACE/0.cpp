void f_filled ( double arr [ ] , long long n ) {  // Patch 2  // Patch 2 // Patch 3  // Patch 2  // Patch 2 // Patch 3 // Patch 4  // Patch 2  // Patch 2 // Patch 3  // Patch 2  // Patch 2 // Patch 3 // Patch 4 // Patch 5
  int maxIdx = n - 1 ;
  int minIdx = 0 ;
  int maxElem = arr [ n - 1 ] + 1 ;
  
  
  for (int i = 0; i<n; ++i) { // Patch 1
    if ( i % 2 == 0 ) {
      arr [ i ] += ( arr [ maxIdx ] % maxElem ) * maxElem ;
      maxIdx -- ;
    }
    else {
      arr [ i ] += ( arr [ minIdx ] % maxElem ) * maxElem ;
      minIdx ++ ;
    }
  }
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    arr [ i ] = arr [ i ] / maxElem ;
  }
}






