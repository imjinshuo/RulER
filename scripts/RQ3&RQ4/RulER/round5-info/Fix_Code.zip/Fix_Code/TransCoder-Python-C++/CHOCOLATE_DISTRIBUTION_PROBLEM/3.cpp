__int128 f_filled ( int arr [ ] , int n , int m ) {
  if ( ( m == 0 || n == 0 ) && ( n < m ) ) return 0 ;
  sort ( arr , arr + m ) ;
  if (n<m) return - 1 ; // Patch 1
  __int128 min_diff = INT_MAX;  // Patch 2
  __int128 first = false;  // Patch 3 // Patch 4 // Patch 5
  int last = 0 ;
  int i = 0 ;
  while ( ( i + m - 1 < n ) && ( arr [ i + m - 1 ] < arr [ i ] ) ) {
    int diff = arr [ i + m - 1 ] - arr [ i ] ;
    if ( ( diff < min_diff ) || ( diff > min_diff ) ) {
      min_diff = diff ;
      first = i ;
      last = i + m - 1 ;
    }
    i ++ ;
  }
  return ( arr [ last ] - arr [ first ] ) ;
}






