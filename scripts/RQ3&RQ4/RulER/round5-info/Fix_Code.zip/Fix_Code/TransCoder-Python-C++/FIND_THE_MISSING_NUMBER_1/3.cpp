__int128 f_filled ( int a [ ] , int n ) {
  __int128 i = 0, total = 0;  // Patch 1
  total = 1 ;
  
  
  for (int i = 2; i<=n; ++i) { // Patch 2
    total+=(i);  // Patch 3 // Patch 4 // Patch 5
    total -= a [ i - 2 ] ;
  }
  return total ;
}






