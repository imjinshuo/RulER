int f_filled ( int n ) {
  int x = 0 ;
  int res = 0 ;
  int yCount = 0 ;
  while (yCount*yCount<n) yCount = yCount + 1 ; // Patch 1
  while (yCount!=0&&(x*x+(yCount-0)*(yCount-0)>=n)) { // Patch 2
    yCount = yCount - 1 ;
  }
  return res ;
}



