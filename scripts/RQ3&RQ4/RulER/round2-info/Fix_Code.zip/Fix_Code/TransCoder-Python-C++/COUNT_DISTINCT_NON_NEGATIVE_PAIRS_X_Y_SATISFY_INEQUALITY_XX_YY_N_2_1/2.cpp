int f_filled ( int n ) {
  int x = 0 ;
  int res = 0 ;
  int yCount = 0 ;
  while (yCount*yCount<n) yCount = yCount + 1 ; // Patch 1
  while (yCount!=1&&(x*x+(yCount-1)*(yCount-1)>=n)) { // Patch 2
    yCount = yCount - 1 ;
  }
  return res ;
}



