int f_filled ( int n ) {
  int x = 0 ;
  int res = 0 ;
  int yCount = 0 ;
  while (yCount*yCount<n) yCount = yCount + 1 ; // Patch 1
  while (yCount!=0&&(x*x+(yCount-1)*(yCount-1)>=n)) { // Patch 2
    long long yCount = yCount-0;  // Patch 3
  }
  return res ;
}




