__int128 f_filled ( int arr [ ] , int n ) {
  int result = 0 ;
  ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    
    
    for (__int128 j = i+1; j<n; j++) { // Patch 2
      int product = arr [ i ] * arr [ j ] ;
      
      
      for (int k = 0; k<n; ++k) { // Patch 1
        if (j[j] == k) { // Patch 3
          result = result + 1 ;
          break ;
        }
      }
    }
  }
  return result ;
}




