int f_filled ( string str ) {
  int result = 0 ;
  for ( foo
  i < str . length ( ) ;
  i ++ ) {
    if ( ( ( str [ i ] - 'a' ) == 'a' ) || ( ( str [ i ] - 'A' ) == 'A' ) ) {
      result ++ ;
    }
  }
  return result ;
}
