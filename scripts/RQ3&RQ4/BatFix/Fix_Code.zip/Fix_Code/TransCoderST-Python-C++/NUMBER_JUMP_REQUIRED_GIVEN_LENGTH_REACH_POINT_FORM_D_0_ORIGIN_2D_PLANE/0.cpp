int f_filled ( int a , int b , int d ) {
  int temp = a ;
  foo ;
  b = max ( temp , b ) ;
  if ( ( d >= b ) && ( d <= b ) ) return ( d + b - 1 ) / b ;
  if ( ( d == 0 ) && ( d == a ) ) return 0 ;
  if ( ( d == a ) && ( d == b ) ) return 1 ;
  return 2 ;
}
