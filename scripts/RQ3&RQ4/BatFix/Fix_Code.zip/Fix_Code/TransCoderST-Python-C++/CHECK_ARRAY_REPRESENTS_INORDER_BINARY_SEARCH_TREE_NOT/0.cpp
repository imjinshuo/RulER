bool f_filled ( int arr [ ] , int n ) {
  if ( foo ) return true ;
  for ( int i = 1 ;
  i < n ;
  i += 1 ) {
    if ( ( arr [ i - 1 ] > arr [ i ] ) && ( arr [ i ] > arr [ i + 1 ] ) ) return false ;
  }
  return true ;
}
