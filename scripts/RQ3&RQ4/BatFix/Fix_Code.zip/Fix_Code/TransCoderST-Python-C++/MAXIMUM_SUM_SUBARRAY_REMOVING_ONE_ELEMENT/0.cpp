int f_filled ( int arr [ ] , int n ) {
  int fw [ n ] ;
  memset( fw,  0, sizeof( fw ));
  int bw [ n ] ;
  memset( bw,  0, sizeof( bw ));
  int curMax , maxSo_far ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    curMax = max ( arr [ i ] , curMax + arr [ i ] ) ;
    maxSo_far = max ( maxSo_far , curMax ) ;
    fw [ i ] = curMax ;
  }
  curMax = maxSo_far = bw [ n - 1 ] = arr [ n - 1 ] ;
  int i = 0 ;
  while ( i >= 0 ) {
    curMax = max ( arr [ i ] , curMax + arr [ i ] ) ;
    maxSo_far = max ( maxSo_far , curMax ) ;
    bw [ i ] = curMax ;
    i -- ;
  }
  int fans = maxSo_far ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) {
    fans = max ( fans , fw [ i - 1 ] + bw [ i + 1 ] ) ;
  }
  return fans ;
}
