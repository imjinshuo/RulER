int f_filled ( int * arr , int n ) {
  int res = 0 ;
  for ( foo
  i <= n - 1 ;
  i ++ ) res = res ^ ( i + 1 ) ^ arr [ i ] ;
  res = res ^ arr [ n - 1 ] ;
  return res ;
}
