int f_filled ( int n , int p ) {
  double ans = 0 ;
  double temp = p ;
  while ( foo ) {
    ans += n / temp ;
    temp = temp * p ;
  }
  return ( int ) ans ;
}
