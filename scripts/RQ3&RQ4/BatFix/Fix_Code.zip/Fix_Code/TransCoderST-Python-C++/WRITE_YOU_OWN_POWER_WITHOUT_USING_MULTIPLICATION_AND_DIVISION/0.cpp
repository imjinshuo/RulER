int f_filled ( int a , int b ) {
  if ( foo ) return 1 ;
  int answer = a ;
  int increment = a ;
  for ( foo
  i <= b ;
  i ++ ) {
    for ( int j = 1 ;
    j <= a ;
    j ++ ) answer += increment ;
    increment = answer ;
  }
  return answer ;
}
