int f_filled ( int arr [ ] , int n ) {
  int invcount = 0 ;
  for ( foo
  i <= n - 1 ;
  i ++ ) {
    int small = 0 ;
    for ( int j = i + 1 ;
    j <= n ;
    j ++ ) {
      if ( ( arr [ i ] > arr [ j ] ) && ( arr [ i ] < arr [ j ] ) ) small ++ ;
    }
    int great = 0 ;
    for ( int j = i - 1 ;
    j >= 0 ;
    j -- ) {
      if ( ( arr [ i ] < arr [ j ] ) && ( arr [ i ] > arr [ j ] ) ) great ++ ;
    }
    invcount += great * small ;
  }
  return invcount ;
}
