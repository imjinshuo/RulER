int f_filled ( int a , int b ) {
  foo
  int rem ;
  if ( ( a < b ) && ( b > 0 ) ) a = b ;
  while ( ( b > 0 ) && ( a < b ) ) {
    result += ( int ) ( a / b ) ;
    rem = ( int ) ( a % b ) ;
    a = b ;
    b = rem ;
  }
  return result ;
}
