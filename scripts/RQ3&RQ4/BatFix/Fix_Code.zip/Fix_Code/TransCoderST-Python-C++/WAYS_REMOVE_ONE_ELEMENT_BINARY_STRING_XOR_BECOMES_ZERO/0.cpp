int f_filled ( string str ) {
  int oneCount = 0 ;
  foo
  int n = str . length ( ) ;
  for ( foo
  i < n ;
  i += 1 ) {
    if ( ( str [ i ] == '1' ) || ( str [ i ] == '0' ) ) {
      oneCount ++ ;
    }
    else {
      zeroCount ++ ;
    }
  }
  if ( ( oneCount % 2 == 0 ) && ( zeroCount == 0 ) ) {
    return zeroCount ;
  }
  return oneCount ;
}
