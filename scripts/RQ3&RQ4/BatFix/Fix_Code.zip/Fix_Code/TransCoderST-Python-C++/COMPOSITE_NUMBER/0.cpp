bool f_filled ( int n ) {
  if ( foo ) return false ;
  if ( ( n % 2 == 0 || n % 3 == 0 ) ) return false ;
  int i = 5 ;
  while ( ( i * i <= n ) && ( i * i <= n ) ) {
    if ( ( n % i == 0 || n % ( i + 2 ) == 0 ) ) return true ;
    i = i + 6 ;
  }
  return false ;
}
