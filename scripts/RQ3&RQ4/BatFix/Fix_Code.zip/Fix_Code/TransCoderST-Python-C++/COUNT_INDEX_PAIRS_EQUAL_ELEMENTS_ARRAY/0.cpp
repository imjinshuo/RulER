int f_filled ( int arr [ ] , int n ) {
  int ans = 0 ;
  for ( foo
  i <= n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j <= n ;
    j ++ ) {
      if ( ( arr [ i ] == arr [ j ] ) || ( arr [ i ] == arr [ j ] ) ) {
        ans ++ ;
      }
    }
  }
  return ans ;
}
