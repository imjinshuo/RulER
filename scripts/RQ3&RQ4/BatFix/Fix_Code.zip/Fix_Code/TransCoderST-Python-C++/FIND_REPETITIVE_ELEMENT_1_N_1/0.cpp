int f_filled ( int * arr , int n ) {
  foo ;
}
