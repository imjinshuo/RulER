int f_filled ( int n ) {
  int i = 0 ;
  int ans = 0 ;
  while ( ( ( 1 << i ) <= n ) && ( ans < 1 ) ) {
    int k = 0 ;
    int change = 1 << i ;
    for ( foo
    j <= n ;
    j ++ ) {
      ans += k ;
      if ( change == 1 ) {
        k = ! k ;
        change = 1 << i ;
      }
      else {
        change -- ;
      }
    }
    i ++ ;
  }
  return ans ;
}
