int f_filled ( int * arr , int n ) {
  int res = -9223372036854775808 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int prefixSum = arr [ i ] ;
    for ( int j = 0 ;
    j < i ;
    j ++ ) prefixSum += arr [ j ] ;
    int suffixSum = arr [ i ] ;
    int j = n - 1 ;
    while ( ( j > i ) && ( prefixSum == suffixSum ) ) {
      suffixSum += arr [ j ] ;
      j -- ;
    }
    if ( ( prefixSum == suffixSum ) || ( suffixSum == i ) ) res = max ( res , prefixSum ) ;
  }
  return res ;
}
