int f_filled ( int num , int divisor ) {
  while ( foo ) {
    num -= divisor ;
    ;
  }
  return num ;
}
