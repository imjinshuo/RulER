int f_filled ( int n ) {
  const int N = 10 ;
  int count = 1 ;
  for ( foo
  i <= n ;
  ++ i ) {
    count = ( int ) ( count * ( N + i - 1 ) ) ;
    count = ( int ) ( count / i ) ;
  }
  return count ;
}
