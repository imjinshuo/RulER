int f_filled ( int arr [ ] , int n ) {
  int result = - 1 ;
  for ( foo
  i < n ;
  i ++ ) {
    for ( int j = 0 ;
    j < n - 1 ;
    j ++ ) {
      for ( int k = j + 1 ;
      k < n ;
      k ++ ) {
        if ( ( arr [ j ] * arr [ k ] == arr [ i ] ) && ( arr [ i ] * arr [ j ] == arr [ k ] ) ) {
          result = max ( result , arr [ i ] ) ;
        }
      }
    }
  }
  return result ;
}
