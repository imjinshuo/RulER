int f_filled ( int arr [ ] , int n ) {
  int res = 1 ;
  for ( foo
  i <= n ;
  i ++ ) {
    if ( arr [ i ] <= res ) {
      res = res + arr [ i ] ;
    }
    else {
      break ;
    }
  }
  return res ;
}
