int f_filled ( double x , double y ) {
  double res1 = foo ;
  ;
  double res2 = log ( y ) / log ( x ) ;
  ;
  return 1 == ( res1 == res2 ) ? 0 : 1 ;
}
