int f_filled ( int n ) {
  if ( foo ) return n ;
  return max ( ( f_filled ( n / 2 ) + f_filled ( n / 3 ) + f_filled ( n / 4 ) ) , n ) ;
}
