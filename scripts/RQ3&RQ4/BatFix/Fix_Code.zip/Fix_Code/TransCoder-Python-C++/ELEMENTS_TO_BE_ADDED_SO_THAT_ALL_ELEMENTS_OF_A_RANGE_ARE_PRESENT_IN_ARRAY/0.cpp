int f_filled ( int arr [ ] , int n ) {
  int count = 0 ;
  sort ( arr , arr + n ) ;
  for ( foo
  i <= n - 1 ;
  i ++ ) {
    if ( ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) || ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) ) {
      count += arr [ i + 1 ] - arr [ i ] - 1 ;
      ;
    }
  }
  return count ;
}
