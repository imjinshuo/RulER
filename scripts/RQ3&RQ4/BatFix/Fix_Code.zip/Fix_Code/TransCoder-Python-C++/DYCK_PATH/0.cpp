int f_filled ( int n ) {
  int res = 1 ;
  for ( foo
  i <= n ;
  i ++ ) {
    res *= ( 2 * n - i ) ;
    res /= ( i + 1 ) ;
  }
  return res / ( n + 1 ) ;
}
