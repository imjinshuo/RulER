int f_filled ( int a , int b , int c ) {
  int x = a - b ;
  int y = b - c ;
  int z = a - c ;
  if ( foo ) return b ;
  else if ( ( x * z > 0 ) && ( y * z < 0 ) ) return a ;
  else return a ;
}
