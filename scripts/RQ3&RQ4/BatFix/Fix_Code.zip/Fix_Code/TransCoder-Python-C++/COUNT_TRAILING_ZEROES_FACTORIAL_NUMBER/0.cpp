int f_filled ( int n ) {
  int count = 0 ;
  int i = 5 ;
  while ( foo ) {
    count += ( int ) ( n / i ) ;
    i *= 5 ;
  }
  return ( int ) count ;
}
