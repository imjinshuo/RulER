int f_filled ( int n , int k ) {
  if ( foo ) return ( k - 1 ) ;
  else return ( 2 * n + 1 - k ) ;
}
