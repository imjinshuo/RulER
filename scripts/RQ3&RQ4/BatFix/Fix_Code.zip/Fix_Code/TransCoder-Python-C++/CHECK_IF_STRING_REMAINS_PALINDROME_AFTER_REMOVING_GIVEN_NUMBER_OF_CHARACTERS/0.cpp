bool f_filled ( string str , int n ) {
  int l = str . length ( ) ;
  if ( foo ) return true ;
  return false ;
}
