bool f_filled ( int a [ ] , int b [ ] , int n , int k ) {
  std :: sort ( a , a + n ) ;
  std :: sort ( b , b + n ) ;
  for ( int32_t i = 0 ;
  i < n ;
  i ++ )
    if ( a [ i ] + b [ i ] < k )
      return false ;
  return true ;
}
