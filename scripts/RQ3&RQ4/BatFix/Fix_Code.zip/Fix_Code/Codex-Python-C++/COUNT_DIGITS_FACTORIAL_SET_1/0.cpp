int f_filled ( int n ) {
        if ( n < 0 ) {
            return 0;
        }

        if ( foo ) {
            return 1;
        }

        int digits = 0;

        for ( foo i <= n; i++ ) {
            digits += log10 ( i );
        }

        return floor ( digits ) + 1;
    }
