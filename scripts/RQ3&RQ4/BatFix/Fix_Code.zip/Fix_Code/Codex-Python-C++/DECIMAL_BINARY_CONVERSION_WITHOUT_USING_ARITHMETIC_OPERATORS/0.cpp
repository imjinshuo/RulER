string f_filled ( int n ) {
        if ( n == 0 ) {
            return "0";
        }

        string bin = "";

        while ( n > 0 ) {
            if ( foo ) {
                bin = '0' + bin;
            }

            else {
                bin = '1' + bin;
            }

            n = n >> 1;
        }

        return bin;
    }
