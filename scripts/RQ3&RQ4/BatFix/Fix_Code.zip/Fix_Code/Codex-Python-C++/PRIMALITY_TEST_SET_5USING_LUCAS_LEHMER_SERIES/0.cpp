bool f_filled ( int p ) {
    int checkNumber = pow ( 2, p ) - 1;
    foo
    for ( foo i < p - 1; i++ ) {
        nextval = ( nextval * nextval - 2 ) % checkNumber;
    }
    if ( nextval == 0 ) {
        return true;
    } else {
        return false;
    }
    }
