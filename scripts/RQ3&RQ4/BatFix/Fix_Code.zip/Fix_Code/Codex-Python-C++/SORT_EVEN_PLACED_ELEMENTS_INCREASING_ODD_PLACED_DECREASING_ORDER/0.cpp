void f_filled ( int arr [ ] , int n ) {
    int evenArr [ n ] ;
    int oddArr [ n ] ;
    int i , j ;
    for ( i = 0 ; i < n ; i ++ ) {
        if ( ( i % 2 ) == 0 ) {
            evenArr [ i ] = arr [ i ] ;
        } else {
            oddArr [ i ] = arr [ i ] ;
        }
    }
    sort ( evenArr , evenArr + n ) ;
    sort ( oddArr , oddArr + n ) ;
    reverse ( oddArr , oddArr + n ) ;
    i = 0 ;
    for ( j = 0 ; j < n ; j ++ ) {
        arr [ i ] = evenArr [ j ] ;
        i ++ ;
    }
    for ( j = 0 ; j < n ; j ++ ) {
        arr [ i ] = oddArr [ j ] ;
        i ++ ;
    }
    }
