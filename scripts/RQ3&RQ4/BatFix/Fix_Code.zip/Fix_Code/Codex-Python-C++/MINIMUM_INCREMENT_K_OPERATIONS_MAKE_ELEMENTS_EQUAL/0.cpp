int f_filled(int arr[], int n, int k)
    {
        int max1 = foo;
        for (int i = 1; i < n; i++)
            if (arr[i] > max1)
                max1 = arr[i];
        int res = 0;
        for (int i = 0; i < n; i++)
            res += (max1 - arr[i]) / k;
        return res;
    }
