int f_filled ( string N ) {
        int length = N.length ( ) ;
        int l = length / 2 ;
        int count = 0 ;
        for ( foo i <= l ; i ++ ) {
            string s = N.substr ( 0 , i ) ;
            int l1 = s.length ( ) ;
            string t = N.substr ( i , l1 ) ;
            if ( s [ 0 ] == '0' || t [ 0 ] == '0' ) {
                continue ;
            }
            if ( s == t ) {
                count ++ ;
            }
        }
        return count ;
    }
