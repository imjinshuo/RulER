int f_filled ( int arr [ ], int n ) {
        int fw [ n ] ;
        memset( fw,  0, sizeof( fw ));
        int bw [ n ] ;
        memset( bw,  0, sizeof( bw ));
        int cur_max, max_so_far = arr [ 0 ] ;
        for ( int i = 0 ; i < n ; i ++ ) {
            cur_max = max ( arr [ i ], cur_max + arr [ i ] ) ;
            max_so_far = max ( max_so_far, cur_max ) ;
            fw [ i ] = cur_max ;
        }
        cur_max = max_so_far = bw [ n - 1 ] = arr [ n - 1 ] ;
        int i = 0 ;
        while ( i >= 0 ) {
            cur_max = max ( arr [ i ], cur_max + arr [ i ] ) ;
            max_so_far = max ( max_so_far, cur_max ) ;
            bw [ i ] = cur_max ;
            i -= 1 ;
        }
        int fans = max_so_far ;
        for ( int i = 0 ; i < n - 1 ; i ++ ) {
            fans = max ( fans, fw [ i - 1 ] + bw [ i + 1 ] ) ;
        }
        return fans ;
    }
