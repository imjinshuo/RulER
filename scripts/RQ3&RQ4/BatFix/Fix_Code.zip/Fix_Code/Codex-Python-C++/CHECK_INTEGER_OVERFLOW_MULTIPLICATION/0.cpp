bool f_filled ( int a, int b ) {
        if ( a == 0 || b == 0 ) {
            return false;
        }
        int result = a * b;
        if ( foo ) {
            result = 0;
        }
        if ( a == ( result / b ) ) {
            return false;
        } else {
            return true;
        }
    }
