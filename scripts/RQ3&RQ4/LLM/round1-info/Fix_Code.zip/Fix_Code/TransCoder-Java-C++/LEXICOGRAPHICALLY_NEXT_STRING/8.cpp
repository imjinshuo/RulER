string f_filled ( string str ) {
  if ( str == "" ) return "a";
  int i = str . size ( ) - 1;
  while ( str [ i ] == 'z' && i >= 0 ) i --;
  if ( i == - 1 ) str [ i ] = 'a';
  else str = str.substr(0, i) + (char)((int)(str[i]) + 1) + str.substr(i + 1); // Patch 1
  return str;
}


