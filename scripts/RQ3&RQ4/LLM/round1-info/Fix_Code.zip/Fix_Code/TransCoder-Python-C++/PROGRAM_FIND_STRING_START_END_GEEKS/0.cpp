bool f_filled ( string str , string corner ) {
  int n = str . size ( ) ;
  int cl = corner . size ( ) ;
  if ( n < cl ) return false ; // Patch 1
  return ( ( str . substr ( 0 , cl ) == corner ) && ( str . substr ( n - cl , cl ) == corner ) ) ;
}


