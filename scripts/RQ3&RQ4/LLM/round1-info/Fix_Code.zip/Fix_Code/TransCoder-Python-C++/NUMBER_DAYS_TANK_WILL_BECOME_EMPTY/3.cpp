int f_filled ( int C , int l ) {
  if ( l >= C ) return C ; // Patch 1
  double eq_root = ( sqrt ( 1 + 8 * ( C - l ) ) - 1 ) / 2 ;
  return ceil ( eq_root ) + l ;
}


