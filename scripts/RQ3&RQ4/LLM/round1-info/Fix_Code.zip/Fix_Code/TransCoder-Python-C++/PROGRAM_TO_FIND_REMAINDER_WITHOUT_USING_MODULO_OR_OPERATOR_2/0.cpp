int f_filled ( int num , int divisor ) {
  while ( num >= divisor ) { // Patch 1
    num -= divisor ;
    ;
  }
  return num ;
}


