int f_filled ( int a [ ] , int n ) {
  if ( n == 1 )
    return a [ 0 ] ;
  int max_neg = -2147483648; // Patch 1
  int countNeg = 0 , countZero = 0 ;
  int prod = 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( a [ i ] == 0 ) {
      countZero ++ ;
      continue ;
    }
    if ( a [ i ] < 0 ) {
      countNeg ++ ;
        max_neg = max ( max_neg , a [ i ] ) ;
    }
    prod = prod * a [ i ] ;
  }
  if ( countZero == n )
    return 0 ;
  if ( countNeg % 2 == 1 ) {
    if ( countNeg == 1 && countZero > 0 && countZero + countNeg == n ) return 0 ;
    prod = prod / max_neg ;
  }
  return prod ;
}


