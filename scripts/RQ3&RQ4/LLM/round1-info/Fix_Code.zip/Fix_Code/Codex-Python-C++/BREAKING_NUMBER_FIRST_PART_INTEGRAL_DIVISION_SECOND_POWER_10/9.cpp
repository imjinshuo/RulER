int f_filled ( string N ) {
        int length = N.length ( ) ;
        int l = length / 2 ;
        int count = 0 ;
        for ( int i = 0 ; i <= l ; i ++ ) {
            string s = N.substr ( 0 , i ) ;
            int l1 = s.length ( ) ;
            string t = N.substr ( i , l1 ) ;
            if ( !s.empty() && ( s[0] == '0' || ( !t.empty() && t[0] == '0' ) ) ) { // Patch 1
                continue ;
            }
            if ( s == t ) {
                count ++ ;
            }
        }
        return count ;
    }


