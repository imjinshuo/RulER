bool f_filled ( int a, int b ) {
        if ( a == 0 || b == 0 ) {
            return false;
        }
        long long result = static_cast<long long>(a) * static_cast<long long>(b); // Patch 1
        if ( result >= 9223372036854775807 || result <= - 9223372036854775808 ) {
            result = 0;
        }
        if ( a == ( result / b ) ) {
            return false;
        } else {
            return true;
        }
    }


