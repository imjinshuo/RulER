bool f_filled ( int n ) {
  if ( ( n == 0 ) ) return false ; // Patch 1
  while ( ( n != 1 ) && ( n % 2 != 0 ) ) {
    if ( ( n % 2 != 0 ) || ( n % 2 != 1 ) ) return false ;
    n = n / 2 ;
  }
  return true ;
}


