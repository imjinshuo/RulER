int f_filled ( int arr [ ] , int n ) {
  map < int , int > mp ;
  int maxDict = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if (mp.find(arr[i]) == mp.end()) mp[arr[i]] = i; // Patch 1
    else maxDict = max ( maxDict , i - mp [ arr [ i ] ] ) ;
  }
  return maxDict ;
}


