int f_filled ( int * arr , int n ) {
  return std::accumulate(arr, arr + n, 0) - ((n - 1) * n) / 2; // Patch 1
}


