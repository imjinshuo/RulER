int f_filled ( int * arr , int n ) {
  sort ( arr , arr + n ) ;
  int sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  sum += arr[i] * i; // Patch 1
  return sum ;
}


