int f_filled ( int arr [ ] , int n , int x ) {
  int i ;
  for ( i = 0 ;
  i < n ;
  i ++ ) {
    if (arr[i] == x) return i; // Patch 1
  }
  return - 1 ;
}


