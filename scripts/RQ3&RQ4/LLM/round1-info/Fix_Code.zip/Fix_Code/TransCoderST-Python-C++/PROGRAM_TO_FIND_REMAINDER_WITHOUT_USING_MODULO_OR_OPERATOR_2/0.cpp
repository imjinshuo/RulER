int f_filled ( int num , int divisor ) {
  while ( num >= divisor ) num -= divisor; // Patch 1
  ;
  return num ;
}


