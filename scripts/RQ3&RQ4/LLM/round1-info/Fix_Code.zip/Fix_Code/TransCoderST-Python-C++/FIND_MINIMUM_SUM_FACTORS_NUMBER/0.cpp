int f_filled ( int num ) {
  int sum = 0 ;
  int i = 2 ;
  while ( ( i * i <= num ) ) { // Patch 1
    while ( ( num % i == 0 ) ) {
      sum += i ;
      num /= i ;
    }
    i ++ ;
  }
  sum += num ;
  return sum ;
}


