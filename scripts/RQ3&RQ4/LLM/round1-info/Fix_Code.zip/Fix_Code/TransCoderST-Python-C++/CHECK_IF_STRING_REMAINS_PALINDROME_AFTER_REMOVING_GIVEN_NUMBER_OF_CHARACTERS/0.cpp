bool f_filled ( string str , int n ) {
  int l = str . length ( ) ;
  if ( l >= n ) return true ; // Patch 1
  return false ;
}


