int f_filled ( int x ) {
  if ( ( x == 0 || x == 1 ) ) return x ;
  int i = 1 ;
  ;
  int result = 1 ;
  while ( result <= x ) { // Patch 1
    i ++ ;
    result = i * i ;
  }
  return i - 1 ;
}


