int f_filled ( string str ) {
  int result = 0 ;
  for ( int i = 0 ;
  i < str . length ( ) ;
  i ++ ) {
    if ( ( ( str[i] - 'a' ) == i ) || ( ( str[i] - 'A' ) == i ) ) { // Patch 1
      result ++ ;
    }
  }
  return result ;
}


