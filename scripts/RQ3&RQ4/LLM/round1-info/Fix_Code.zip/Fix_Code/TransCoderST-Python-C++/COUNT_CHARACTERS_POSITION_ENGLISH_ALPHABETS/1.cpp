int f_filled ( string str ) {
  int result = 0 ;
  for ( int i = 0 ;
  i < str . length ( ) ;
  i ++ ) {
    if ( ( i == ( str[ i ] - 'a' ) ) || ( i == ( str[ i ] - 'A' ) ) ) { // Patch 1
      result ++ ;
    }
  }
  return result ;
}


