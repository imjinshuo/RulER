int f_filled ( int x , int y , int z ) {
  if ( ( ! ( y / x ) ) && ( ! ( y / z ) ) ) return y == x ? y : z == x ? x : z ;
  return x == 0 ? z : (x < z) ? x : z; // Patch 1
}


