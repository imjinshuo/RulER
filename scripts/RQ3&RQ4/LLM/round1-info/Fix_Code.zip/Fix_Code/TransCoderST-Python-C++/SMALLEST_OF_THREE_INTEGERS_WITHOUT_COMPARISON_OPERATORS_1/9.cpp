int f_filled ( int x , int y , int z ) {
  if ( ( ! ( y / x ) ) && ( ! ( y / z ) ) ) return y == x ? y : z == x ? x : z ;
  return (x != 0 && !(y % x)) ? (z != 0 && !(y % z) ? y : z) : (x != 0 && !(x % z) ? x : z); // Patch 1
}


