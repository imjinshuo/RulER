int f_filled ( int x , int y ) {
  while ( y != 0 ) { // Patch 1
    int carry = x & y ;
    x = x ^ y ;
    y = carry << 1 ;
  }
  return x ;
}


