int f_filled ( int arr [ ] , int n , int x ) {
  int i = 0 ;
  while ( ( i < n ) && ( arr [ i ] != x ) ) { // Patch 1
    i = i + abs(arr[i] - x); // Patch 3
    i = i + abs ( arr [ i ] - x ) ;
  }
  cout << "number is not present!" << endl ;
  return - 1 ;
}




