string f_filled ( string text , int s ) {
  string result ;
  for ( int i = 0 ;
  i < text . length ( ) ;
  i ++ ) {
    char c = text [ i ] ;
    if ( c >= 'A' && c <= 'Z' ) // Patch 2
        result += ( char ) ( ( ( c - 65 ) + s ) % 26 + 65 ) ; // Patch 1
    else
        result += ( char ) ( ( ( c - 97 + s ) % 26 + 97 ) ); // Patch 3
  }
  return result ;
}




