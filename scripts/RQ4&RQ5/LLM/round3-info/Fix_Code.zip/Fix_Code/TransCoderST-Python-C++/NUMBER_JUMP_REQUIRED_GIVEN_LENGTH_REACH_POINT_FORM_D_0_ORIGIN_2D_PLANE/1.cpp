int f_filled ( int a , int b , int d ) {
  int temp = a ;
  a = min ( a , b ) ;
  b = max ( temp , b ) ;
  if ( ( d >= b ) ) return ( d + b - 1 ) / b ; // Patch 1
  if ( ( d == 0 ) ) return 0 ; // Patch 3
  if ( ( d == a ) && ( d == b ) ) return 1 ;
  return 2 ;
}




