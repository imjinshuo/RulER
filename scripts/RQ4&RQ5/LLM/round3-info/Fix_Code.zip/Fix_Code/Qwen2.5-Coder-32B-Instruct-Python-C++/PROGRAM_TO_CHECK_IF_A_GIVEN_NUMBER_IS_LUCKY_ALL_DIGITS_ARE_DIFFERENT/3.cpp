bool f_filled(int n) { // Patch 3
    int ar[10] = {0};
    while (n > 0) {
        int digit = std::floor(n % 10);
        if (ar[digit]) {
            return false;
        }
        ar[digit] = 1;
        n = n / 10;
    }
    return true;
}



