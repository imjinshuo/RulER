int f_filled ( int arr [ ] , int n ) {
  int result = 0 ;
  ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j < n ; // Patch 2
    j ++ ) {
      int product = arr [ i ] * arr [ j ] ;
      for ( int k = 0 ;
      k < n ; // Patch 1
      k ++ ) {
        if ( arr[k] == product ) { // Patch 3
          result = result + 1 ;
          break ;
        }
      }
    }
  }
  return result ;
}




