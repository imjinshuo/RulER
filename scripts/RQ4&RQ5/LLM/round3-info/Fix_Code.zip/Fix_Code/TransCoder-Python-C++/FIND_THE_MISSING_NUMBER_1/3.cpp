int f_filled ( int a [ ] , int n ) {
  int i = 2, total = 1; // Patch 1
  // No need to add anything here as total is already initialized. // Patch 2
  for ( i = 2 ;
  i <= n ;
  i++ ) { // Patch 3
    total += i ;
    total -= a [ i - 2 ] ;
  }
  return total ;
}




