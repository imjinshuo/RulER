int f_filled ( int arr [ ] , int n ) {
  vector < int > s ;
  int first = INT_MIN; // Patch 2
  int second = INT_MIN; // Similar initialization to ensure proper comparison // Patch 3
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if (std::find(s.begin(), s.end(), arr[i]) == s.end()) { // Patch 1
      s . push_back ( arr [ i ] ) ;
      continue ;
    }
    if ( ( arr [ i ] > first ) && ( arr [ i ] < second ) ) {
      second = first ;
      first = arr [ i ] ;
    }
    else if ( ( arr [ i ] > second ) && ( arr [ i ] < first ) ) {
      second = arr [ i ] ;
    }
  }
  return ( first * second ) ;
}




