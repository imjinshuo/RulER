int f_filled ( int a , int b ) {
  int count = 0 ;
  int p = abs ( a * b ) ;
  if ( p == 0 ) return 1; // Patch 1
  while ( p > 0 ) { // Patch 2
    count = count + 1 ;
    p = p / 10 ;
  }
  return count ;
}



