int f_filled ( string s1 , string s2 , int index ) {
  s2 [ index ] = s1 [ index ] ;
  ;
  if ( index != s1.length() - 1 ) f_filled(s1, s2, index + 1); // Patch 1
  ;
  return index; // Patch 2
}


