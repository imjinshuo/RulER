int f_filled ( int a [ ] , int n ) {
  int i, total = 1; // Patch 1
  for ( i = 2 ;
  i <= n + 1 ; // Patch 2
  i ++ ) {
    total += i ;
    total -= a [ i - 2 ] ;
  }
  return total ;
}



