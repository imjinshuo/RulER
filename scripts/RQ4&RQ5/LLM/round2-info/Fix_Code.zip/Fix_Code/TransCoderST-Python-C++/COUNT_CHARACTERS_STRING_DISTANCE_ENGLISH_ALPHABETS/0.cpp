int f_filled ( string str1 ) {
  int result = 0 ;
  int n = str1 . length ( ) ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j < n ; // Patch 1
    j ++ ) {
      if ( abs( str1[i] - str1[j] ) == abs( i - j ) ) { // Patch 2
        result ++ ;
      }
    }
  }
  return result ;
}



