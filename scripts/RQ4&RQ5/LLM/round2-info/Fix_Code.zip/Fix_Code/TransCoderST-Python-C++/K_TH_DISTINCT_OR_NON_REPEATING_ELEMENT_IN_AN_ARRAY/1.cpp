int f_filled ( int arr [ ] , int n , int k ) {
  int distCount = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int j = 0 ;
    while ( j < n ) {
      if ( ( i != j && arr [ j ] == arr [ i ] ) || ( j == n ) ) break ;
      j ++ ;
    }
    if ( ( j == n ) && ( arr [ j ] == arr [ i ] ) ) distCount ++ ;
    if ( distCount == k ) return arr[i]; // Patch 1
  if ( j == n ) distCount++; // Patch 2
  return - 1 ;
}



