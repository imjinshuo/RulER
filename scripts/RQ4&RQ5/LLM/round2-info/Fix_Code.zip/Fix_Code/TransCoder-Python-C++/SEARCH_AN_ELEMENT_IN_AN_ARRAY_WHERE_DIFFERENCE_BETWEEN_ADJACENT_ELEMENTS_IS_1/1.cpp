int f_filled ( int arr [ ] , int n , int x ) {
  int i = 0 ;
  while ( i < n ) { // Patch 1
    if ( arr[i] == x ) return i; // Patch 2
    i = i + abs ( arr [ i ] - x ) ;
  }
  cout << "number is not present!" << endl ;
  return - 1 ;
}



