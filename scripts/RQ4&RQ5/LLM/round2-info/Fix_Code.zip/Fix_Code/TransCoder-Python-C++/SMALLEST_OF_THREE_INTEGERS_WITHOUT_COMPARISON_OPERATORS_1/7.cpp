int f_filled ( int x , int y , int z ) {
  if ( ( ! ( y / x ) ) && ( ! ( y / z ) ) ) return y ? ( y / z ) : z ;
  return x ? ( x / z == 0 ? x : z ) : z; // Patch 1
return y ? (x ? (y < x ? (y < z ? y : z) : (x < z ? x : z)) : z) : (x ? (x < z ? x : z) : z); // Patch 2



