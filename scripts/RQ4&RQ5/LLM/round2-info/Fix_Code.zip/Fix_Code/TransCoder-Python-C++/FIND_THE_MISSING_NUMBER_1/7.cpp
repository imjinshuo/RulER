int f_filled ( int a [ ] , int n ) {
  int i = 2, total = 1; // Patch 1
  int total = 1; // Patch 2
  for ( i = 2 ;
  i <= n ;
  i += 2 ) {
    total += i ;
    total -= a [ i - 2 ] ;
  }
  return total ;
}



