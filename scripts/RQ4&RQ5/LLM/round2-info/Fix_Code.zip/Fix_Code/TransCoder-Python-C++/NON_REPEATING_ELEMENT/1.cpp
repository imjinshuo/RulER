int f_filled ( int arr [ ] , int n ) {
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int j = 0 ;
    while ( ( j < n ) && ( arr [ i ] != arr [ j ] ) ) { // Patch 1
      if ( ( i != j ) && ( arr [ i ] == arr [ j ] ) ) break ; // Patch 2
      j ++ ;
    }
    if ( ( j == n ) && ( arr [ i ] == arr [ j ] ) ) return arr [ i ] ;
  }
  return - 1 ;
}



