int f_filled ( int n ) {
  if ( ( n < 0 ) || ( n <= 1 ) ) return 0 ;
  ;
  if ( n == 2 ) return 1; // Patch 1
  ;
  double x = ( ( n * log10 ( n / M_E ) ) + log10 ( 2 * M_PI * n ) / 2.0 ) ; // Patch 2
  ;
  return floor ( x ) + 1 ;
}



