int f_filled ( int arr [ ] , int n , int k ) {
  int dist_count = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int j = 0 ;
    while ( j < n ) {
      if ( ( i != j && arr [ j ] == arr [ i ] ) || ( j == n ) ) break ;
      j ++ ;
    }
    if ( j == n ) dist_count++ ; // Patch 1
    if ( dist_count == k ) return arr[i]; // Patch 2
  }
  return - 1 ;
}



