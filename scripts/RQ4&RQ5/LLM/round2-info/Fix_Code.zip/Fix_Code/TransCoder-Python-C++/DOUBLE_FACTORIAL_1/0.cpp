int f_filled ( int n ) {
  int res = 1 ;
  ;
  for ( int i = n ;
  i >= 0 ;
  i -- ) {
    if ( ( i == 0 || i == 1 ) && ( i != 0 ) ) return res ;
    res *= i; // Patch 1
  i -= 2; // Patch 2
  return res ;
}



