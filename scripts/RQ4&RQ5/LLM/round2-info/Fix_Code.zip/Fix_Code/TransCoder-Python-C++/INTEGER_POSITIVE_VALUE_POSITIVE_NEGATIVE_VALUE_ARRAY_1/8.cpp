int f_filled ( int arr [ ] , int n ) {
  int neg = 0 ;
  int pos = 0 ;
  int sum = 0 ;
  for ( int i = 0 ;
  i < n; // Patch 2
  i ++ ) {
    sum += arr [ i ] ;
    if (arr[i] < 0) neg++; // Patch 1
    else pos ++ ;
  }
  return ( sum / abs ( neg - pos ) ) ;
}



