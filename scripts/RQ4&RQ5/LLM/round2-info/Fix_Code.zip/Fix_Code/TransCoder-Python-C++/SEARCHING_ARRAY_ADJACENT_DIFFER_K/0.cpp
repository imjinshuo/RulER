int f_filled ( int arr [ ] , int n , int x , int k ) {
  int i = 0 ;
  while ( i < n ) { // Patch 1
    if (arr[i] == x) return i; // Patch 2
    i = i + max ( 1 , ( int ) ( abs ( arr [ i ] - x ) / k ) ) ;
  }
  cout << "number is not present!" << endl ;
  return - 1 ;
}



