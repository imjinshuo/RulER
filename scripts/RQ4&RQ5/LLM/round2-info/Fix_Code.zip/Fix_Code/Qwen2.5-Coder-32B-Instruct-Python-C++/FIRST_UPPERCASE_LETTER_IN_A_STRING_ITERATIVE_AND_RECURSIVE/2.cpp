char f_filled(const std::string& str) {
    for (size_t i = 0; i < str.length(); ++i) {
        if (std::isupper(str[i])) {
            return str[i];
        }
    }
    return '\0'; // Patch 1
return '\0'; // Return null character if no uppercase letter is found // Patch 2


