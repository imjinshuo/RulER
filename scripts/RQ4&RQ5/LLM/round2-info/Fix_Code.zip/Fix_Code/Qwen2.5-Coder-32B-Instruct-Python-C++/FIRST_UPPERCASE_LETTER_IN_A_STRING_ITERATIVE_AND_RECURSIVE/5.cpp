char f_filled(const std::string& str) {
    for (size_t i = 0; i < str.length(); ++i) {
        if (std::isupper(str[i])) {
            return str[i];
        }
    }
    return '\0'; // Patch 1
return '\0'; // This line is already present as Patch 1, but for clarity, it's the correct line to be placed at the infill location. // Patch 2


