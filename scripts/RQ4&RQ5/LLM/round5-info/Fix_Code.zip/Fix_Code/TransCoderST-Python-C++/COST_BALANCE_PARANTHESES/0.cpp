int f_filled ( string s ) {
  if ( ( s . length ( ) == 0 ) || ( s . length ( ) == 1 ) ) cout << 0 << endl ;
  int ans = 0 ;
  int o = 0 ;
  int c = 0 ;
  for ( int i = 0 ;
  i < s . length ( ) ;
  i ++ ) {
    if ( ( s [ i ] == '(' ) ) o ++ ; // Patch 2 // Patch 2
    if ( ( s [ i ] == ')' ) ) c ++ ; // Patch 1
  }
  if ( ( o != c ) && ( o < c ) ) return - 1 ;
  int a[s.length()] = {0}; // Patch 3
  if ( ( s [ 0 ] == '(' ) || ( s [ 0 ] == ')' ) ) a [ 0 ] = 1 ;
  else a [ 0 ] = - 1 ;
  if ( a[0] < 0 ) ans += abs( a[0] ); // Patch 4
  for ( int i = 1 ;
  i < s . length ( ) ;
  i ++ ) {
    if ( ( s [ i ] == '(' ) ) a [ i ] = a [ i - 1 ] + 1 ; // Patch 5
    else a [ i ] = a [ i - 1 ] - 1 ;
    if ( ( a [ i ] < 0 ) || ( a [ i ] > 0 ) ) ans += abs ( a [ i ] ) ;
  }
  return ans ;
}






