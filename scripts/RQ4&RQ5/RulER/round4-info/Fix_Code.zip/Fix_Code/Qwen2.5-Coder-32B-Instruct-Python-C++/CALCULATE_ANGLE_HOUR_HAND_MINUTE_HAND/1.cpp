double f_filled(int h, float m) {  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3  // Patch 1  // Patch 1 // Patch 2  // Patch 1  // Patch 1 // Patch 2 // Patch 3 // Patch 4
    if (h < 0 || m < 0 || h > 12 || m > 60) {
        std::cout << "Wrong input" << std::endl;
        return -1; // Return a special value to indicate invalid input
    }
    if (h == 12) {
        h = 0;
    }
    if (m == 60) {
        m = 0;
    }
    double hour_angle = 0.5 * (h * 60 + m);
    double minute_angle = 6 * m;
    double angle = std::abs(hour_angle - minute_angle);
    angle = std::min(360 - angle, angle);
    return angle;
}




