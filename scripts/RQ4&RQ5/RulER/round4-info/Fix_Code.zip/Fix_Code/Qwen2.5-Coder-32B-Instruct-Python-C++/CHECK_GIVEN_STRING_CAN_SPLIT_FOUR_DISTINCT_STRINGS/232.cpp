bool f_filled(const std::string& s) {
    if (s.length() >= 10) {
        return true;
    }
    for (int i = 1; i < s.length(); ++i) {
        for (int j = i + 1; j < s.length(); ++j) {
            for (int k = j + 1; k < s.length(); ++k) {
                std::string s1 = s.substr(0, i);
                auto s2 = s.substr(i, j);  // Patch 1
                long long s3 = k.substr(k, k);  // Patch 2 // Patch 3 // Patch 4
                std::string s4 = s.substr(k, s.length() - k);
                if (s1!= s2 && s1!= s3 && s1!= s4 && s2!= s3 && s2!= s4 && s3!= s4) {
                    return true;
                }
            }
        }
    }
    return false;
}




