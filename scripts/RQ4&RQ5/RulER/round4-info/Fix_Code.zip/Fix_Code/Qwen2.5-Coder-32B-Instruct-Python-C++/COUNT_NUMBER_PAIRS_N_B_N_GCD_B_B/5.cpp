__int128 f_filled(int n) {
    __int128 k = n;  // Patch 1
    __int128 imin = 0;  // Patch 2
    __int128 ans;  // Patch 3 // Patch 4
    while (imin <= n) {
        int imax = n / k;
        ans += k * (imax - imin + 1);
        imin = imax + 1;
        k = n / imin;
    }
    return ans;
}




