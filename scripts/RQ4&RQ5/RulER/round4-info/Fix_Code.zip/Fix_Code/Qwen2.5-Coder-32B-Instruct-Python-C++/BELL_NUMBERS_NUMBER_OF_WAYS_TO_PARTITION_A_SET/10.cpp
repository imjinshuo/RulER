__int128 f_filled(int n) {
    std::vector<std::vector<__int128>> bell(n+1, std::vector<__int128>(n+1, 0));  // Patch 1
    bell[1][1] = 0;  // Patch 2 // Patch 3 // Patch 4
    for (int i = 1; i <= n; i++) {
        bell[i][0] = bell[i - 1][i - 1];
        for (int j = 1; j <= i; j++) {
            bell[i][j] = bell[i - 1][j - 1] + bell[i][j - 1];
        }
    }
    return bell[n][0];
}




